import React, { useState, useMemo } from 'react';
import {
  FileText,
  Plus,
  Trash2,
  Pin,
  Flame,
  Search,
  Eye,
  Edit3,
  Copy,
  Check,
  Clock,
  Tag,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { NoteItem } from '../types';
import { calculateSha256 } from '../lib/crypto';

interface NotepadViewProps {
  notes: NoteItem[];
  onSaveNotes: (updatedNotes: NoteItem[]) => void;
}

export const NotepadView: React.FC<NotepadViewProps> = ({ notes, onSaveNotes }) => {
  const [selectedId, setSelectedId] = useState<string>(notes[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [copied, setCopied] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');

  // Active Note
  const activeNote = useMemo(() => {
    return notes.find(n => n.id === selectedId) || notes[0] || null;
  }, [notes, selectedId]);

  // All distinct tags
  const allTags = useMemo(() => {
    const set = new Set<string>();
    notes.forEach(n => n.tags.forEach(t => set.add(t)));
    return Array.from(set);
  }, [notes]);

  // Filtered Notes
  const filteredNotes = useMemo(() => {
    return notes
      .filter(n => {
        const matchesQuery =
          n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          n.content.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesTag = !selectedTag || n.tags.includes(selectedTag);
        return matchesQuery && matchesTag;
      })
      .sort((a, b) => {
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        return b.updatedAt - a.updatedAt;
      });
  }, [notes, searchQuery, selectedTag]);

  const handleCreateNote = () => {
    const newNote: NoteItem = {
      id: `note-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: 'Untitled Confidential Note',
      content: `# New Encrypted Thought\n\n- Zero telemetry\n- Local RAM memory only\n- Write private thoughts here...`,
      tags: ['Confidential'],
      pinned: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      expiresAt: null,
    };
    const updated = [newNote, ...notes];
    onSaveNotes(updated);
    setSelectedId(newNote.id);
  };

  const handleUpdateActiveNote = (updates: Partial<NoteItem>) => {
    if (!activeNote) return;
    const updated = notes.map(n =>
      n.id === activeNote.id ? { ...n, ...updates, updatedAt: Date.now() } : n
    );
    onSaveNotes(updated);
  };

  const handleDeleteNote = (id: string) => {
    const updated = notes.filter(n => n.id !== id);
    onSaveNotes(updated);
    if (selectedId === id) {
      setSelectedId(updated[0]?.id || '');
    }
  };

  const handleTogglePin = (id: string) => {
    const updated = notes.map(n => (n.id === id ? { ...n, pinned: !n.pinned } : n));
    onSaveNotes(updated);
  };

  const handleAddTag = (tag: string) => {
    if (!activeNote || !tag.trim()) return;
    const cleanTag = tag.trim();
    if (!activeNote.tags.includes(cleanTag)) {
      handleUpdateActiveNote({ tags: [...activeNote.tags, cleanTag] });
    }
    setNewTagInput('');
  };

  const handleRemoveTag = (tag: string) => {
    if (!activeNote) return;
    handleUpdateActiveNote({ tags: activeNote.tags.filter(t => t !== tag) });
  };

  const handleCopyContent = () => {
    if (!activeNote) return;
    navigator.clipboard.writeText(activeNote.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const wordCount = activeNote ? activeNote.content.trim().split(/\s+/).filter(Boolean).length : 0;
  const charCount = activeNote ? activeNote.content.length : 0;

  return (
    <div className="h-[calc(100vh-85px)] flex bg-[#050505] overflow-hidden font-sans">
      {/* Sidebar List */}
      <div className="w-80 border-r border-[#1e1e1e] flex flex-col bg-[#0a0a0a] flex-shrink-0">
        {/* Header & Search */}
        <div className="p-3 border-b border-[#1e1e1e] space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-mono font-semibold uppercase tracking-wider text-[#888888] flex items-center space-x-1.5">
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>Confidential Notes ({notes.length})</span>
            </h2>
            <button
              onClick={handleCreateNote}
              className="p-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-lg text-xs flex items-center space-x-1 transition-colors font-mono"
              title="Create New Encrypted Note"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New</span>
            </button>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#666666]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search notes..."
              className="w-full bg-[#121212] border border-[#222222] rounded-md pl-8 pr-3 py-1.5 text-xs text-[#d4d4d4] placeholder-[#555555] focus:outline-none focus:border-blue-500 font-mono transition-colors"
            />
          </div>

          {/* Tags Chips */}
          {allTags.length > 0 && (
            <div className="flex items-center space-x-1 overflow-x-auto pb-1 text-[10px] font-mono">
              <button
                onClick={() => setSelectedTag(null)}
                className={`px-2 py-0.5 rounded transition-colors whitespace-nowrap border ${
                  selectedTag === null
                    ? 'bg-[#222222] text-white border-[#333333]'
                    : 'bg-[#121212] text-[#777777] border-[#1e1e1e] hover:text-[#d4d4d4]'
                }`}
              >
                All
              </button>
              {allTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag === selectedTag ? null : tag)}
                  className={`px-2 py-0.5 rounded transition-colors whitespace-nowrap border ${
                    selectedTag === tag
                      ? 'bg-blue-950/60 text-blue-200 border-blue-700/60'
                      : 'bg-[#121212] text-[#777777] border-[#1e1e1e] hover:text-[#d4d4d4]'
                  }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Notes Items List */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#1e1e1e]/60">
          {filteredNotes.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#555555] font-mono">
              No confidential notes found.
            </div>
          ) : (
            filteredNotes.map(note => {
              const isSelected = activeNote?.id === note.id;
              return (
                <div
                  key={note.id}
                  onClick={() => setSelectedId(note.id)}
                  className={`p-3 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#141414] border-l-2 border-blue-500'
                      : 'hover:bg-[#0f0f0f]'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <h3 className="text-xs font-semibold text-[#f0f0f0] truncate pr-2 font-mono">
                      {note.title || 'Untitled Note'}
                    </h3>
                    <div className="flex items-center space-x-1 flex-shrink-0">
                      {note.pinned && <Pin className="w-3 h-3 text-amber-400 fill-amber-400/20" />}
                      {note.expiresAt && <Flame className="w-3 h-3 text-orange-400" />}
                    </div>
                  </div>

                  <p className="text-[11px] text-[#888888] line-clamp-2 mt-1 font-sans">
                    {note.content.replace(/[#*`_]/g, '')}
                  </p>

                  <div className="flex items-center justify-between mt-2 text-[10px] font-mono text-[#666666]">
                    <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                    <div className="flex items-center space-x-1">
                      {note.tags.slice(0, 2).map(t => (
                        <span key={t} className="bg-[#181818] border border-[#222222] px-1.5 py-0.2 rounded text-[#888888]">
                          #{t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Editor Panel */}
      {activeNote ? (
        <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden">
          {/* Note Top Bar */}
          <div className="px-5 py-3 border-b border-[#1e1e1e] flex items-center justify-between bg-[#0a0a0a]">
            <input
              type="text"
              value={activeNote.title}
              onChange={e => handleUpdateActiveNote({ title: e.target.value })}
              className="text-base font-semibold text-[#f0f0f0] bg-transparent border-none focus:outline-none focus:ring-0 w-2/3"
              placeholder="Note Title..."
            />

            <div className="flex items-center space-x-2">
              {/* Preview Toggle */}
              <button
                onClick={() => setPreviewMode(!previewMode)}
                className={`p-1.5 rounded text-xs flex items-center space-x-1 border font-mono transition-colors ${
                  previewMode
                    ? 'bg-blue-950/50 border-blue-700/60 text-blue-300'
                    : 'bg-[#141414] border-[#262626] text-[#888888] hover:text-[#d4d4d4]'
                }`}
                title={previewMode ? 'Switch to Markdown Edit Mode' : 'Switch to Rendered Preview'}
              >
                {previewMode ? <Edit3 className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{previewMode ? 'Editor' : 'Preview'}</span>
              </button>

              {/* Pin Toggle */}
              <button
                onClick={() => handleTogglePin(activeNote.id)}
                className={`p-1.5 rounded text-xs border font-mono transition-colors ${
                  activeNote.pinned
                    ? 'bg-amber-950/50 border-amber-700/60 text-amber-300'
                    : 'bg-[#141414] border-[#262626] text-[#888888] hover:text-[#d4d4d4]'
                }`}
                title="Pin Note to Top"
              >
                <Pin className="w-3.5 h-3.5" />
              </button>

              {/* Copy Content */}
              <button
                onClick={handleCopyContent}
                className="p-1.5 rounded text-xs bg-[#141414] border border-[#262626] text-[#888888] hover:text-[#d4d4d4] font-mono transition-colors"
                title="Copy Note Text"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>

              {/* Delete Note */}
              <button
                onClick={() => handleDeleteNote(activeNote.id)}
                className="p-1.5 rounded text-xs bg-red-950/30 border border-red-900/40 text-red-400 hover:text-red-300 font-mono transition-colors"
                title="Shred This Note"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Tags & Meta Strip */}
          <div className="px-5 py-2 border-b border-[#1a1a1a] bg-[#080808] flex items-center justify-between text-xs font-mono">
            <div className="flex items-center space-x-2 flex-wrap gap-y-1">
              <span className="text-[#666666] flex items-center space-x-1">
                <Tag className="w-3 h-3" />
                <span>Tags:</span>
              </span>
              {activeNote.tags.map(t => (
                <span
                  key={t}
                  className="bg-[#141414] border border-[#262626] text-[#cccccc] px-2 py-0.5 rounded-full text-[11px] flex items-center space-x-1"
                >
                  <span>#{t}</span>
                  <button
                    onClick={() => handleRemoveTag(t)}
                    className="text-[#666666] hover:text-red-400 ml-1"
                  >
                    ×
                  </button>
                </span>
              ))}
              <input
                type="text"
                value={newTagInput}
                onChange={e => setNewTagInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag(newTagInput);
                  }
                }}
                placeholder="+ Add tag..."
                className="bg-transparent border-b border-[#262626] text-[11px] text-[#cccccc] px-1 py-0.5 w-20 focus:w-28 focus:outline-none focus:border-blue-500 transition-all"
              />
            </div>

            <div className="text-[11px] text-[#666666] flex items-center space-x-3">
              <span>{wordCount} words</span>
              <span>•</span>
              <span>{charCount} chars</span>
            </div>
          </div>

          {/* Editor Body / Preview Mode */}
          <div className="flex-1 p-6 overflow-y-auto">
            {previewMode ? (
              <div className="markdown-body max-w-4xl mx-auto">
                <ReactMarkdown>{activeNote.content}</ReactMarkdown>
              </div>
            ) : (
              <textarea
                value={activeNote.content}
                onChange={e => handleUpdateActiveNote({ content: e.target.value })}
                className="w-full h-full bg-transparent text-[#d4d4d4] font-mono text-sm leading-relaxed border-none focus:outline-none resize-none placeholder-[#444444]"
                placeholder="Write your encrypted notes here in Markdown..."
                spellCheck={false}
              />
            )}
          </div>

          {/* Footer Security Badge */}
          <div className="px-5 py-1.5 border-t border-[#1a1a1a] bg-[#080808] flex items-center justify-between text-[10px] font-mono text-[#666666]">
            <span className="flex items-center space-x-1 text-blue-400">
              <ShieldCheck className="w-3 h-3" />
              <span>AES-256 Memory Encrypted</span>
            </span>
            <span>Last Modified: {new Date(activeNote.updatedAt).toLocaleTimeString()}</span>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-[#555555] font-mono text-xs">
          <FileText className="w-10 h-10 mb-2 stroke-[1.2]" />
          <span>No note selected. Create one to begin.</span>
        </div>
      )}
    </div>
  );
};
