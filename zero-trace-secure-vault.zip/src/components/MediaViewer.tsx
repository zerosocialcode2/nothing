import React, { useState, useRef } from 'react';
import {
  FileText,
  Image as ImageIcon,
  Music,
  Video,
  Mic,
  MicOff,
  Square,
  Play,
  Pause,
  Download,
  ShieldCheck,
  Sparkles,
  Eye,
  Trash2,
  Upload,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Sliders
} from 'lucide-react';
import { VaultFile } from '../types';
import { stripImageMetadata } from '../lib/crypto';

interface MediaViewerProps {
  files: VaultFile[];
  onSaveFiles: (files: VaultFile[]) => void;
}

export const MediaViewer: React.FC<MediaViewerProps> = ({ files, onSaveFiles }) => {
  const [selectedFileId, setSelectedFileId] = useState<string>(files[0]?.id || '');
  const [filterCategory, setFilterCategory] = useState<'all' | 'image' | 'pdf' | 'audio' | 'video'>('all');
  
  // Voice Memo Recorder state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  // Photo viewer controls
  const [zoomLevel, setZoomLevel] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [exifCleanedNotice, setExifCleanedNotice] = useState(false);

  const selectedFile = files.find(f => f.id === selectedFileId) || files[0] || null;

  const filteredFiles = files.filter(f => {
    if (filterCategory === 'all') return true;
    return f.category === filterCategory;
  });

  // Start Audio Recording
  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = e => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Audio = reader.result as string;
          const newFile: VaultFile = {
            id: `audio-${Date.now()}`,
            name: `Encrypted_Voice_Memo_${new Date().toISOString().slice(0, 16).replace('T', '_')}.webm`,
            size: audioBlob.size,
            mimeType: 'audio/webm',
            category: 'audio',
            dataUrl: base64Audio,
            tags: ['VoiceMemo', 'Confidential'],
            createdAt: Date.now(),
            notes: 'Encrypted client-side voice transmission.',
          };
          const updated = [newFile, ...files];
          onSaveFiles(updated);
          setSelectedFileId(newFile.id);
        };
        reader.readAsDataURL(audioBlob);

        // Stop all audio tracks
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      setIsRecording(true);
      setRecordingDuration(0);
      timerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    } catch (err: any) {
      alert('Microphone access unavailable or denied: ' + (err.message || 'Check browser permissions'));
    }
  };

  // Stop Audio Recording
  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  // Strip EXIF metadata from active photo
  const handleCleanExif = async () => {
    if (!selectedFile || selectedFile.category !== 'image') return;
    try {
      const cleanDataUrl = await stripImageMetadata(selectedFile.dataUrl);
      const updated = files.map(f =>
        f.id === selectedFile.id ? { ...f, dataUrl: cleanDataUrl, exifStripped: true } : f
      );
      onSaveFiles(updated);
      setExifCleanedNotice(true);
      setTimeout(() => setExifCleanedNotice(false), 2000);
    } catch (err) {
      console.error('EXIF cleaning error', err);
    }
  };

  const handleDeleteFile = (id: string) => {
    const updated = files.filter(f => f.id !== id);
    onSaveFiles(updated);
    if (selectedFileId === id) {
      setSelectedFileId(updated[0]?.id || '');
    }
  };

  const handleDownload = (file: VaultFile) => {
    const a = document.createElement('a');
    a.href = file.dataUrl;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-[calc(100vh-85px)] flex bg-[#050505] overflow-hidden font-sans">
      {/* Media Sidebar List */}
      <div className="w-80 border-r border-[#1e1e1e] flex flex-col bg-[#0a0a0a] flex-shrink-0">
        {/* Header & Voice Memo Trigger */}
        <div className="p-3 border-b border-[#1e1e1e] space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-mono font-semibold uppercase tracking-wider text-[#888888] flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Media & Document Hub</span>
            </h2>
          </div>

          {/* Voice Memo Recording Box */}
          <div className="p-2.5 rounded-lg bg-[#121212] border border-[#222222] flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className={`w-2.5 h-2.5 rounded-full ${isRecording ? 'bg-red-500 animate-ping' : 'bg-[#555555]'}`} />
              <span className="text-xs font-mono text-[#d4d4d4]">
                {isRecording ? `Recording (${formatDuration(recordingDuration)})` : 'Voice Thought Memo'}
              </span>
            </div>

            {isRecording ? (
              <button
                onClick={handleStopRecording}
                className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-mono font-semibold flex items-center space-x-1 animate-pulse"
              >
                <Square className="w-3 h-3" />
                <span>Save</span>
              </button>
            ) : (
              <button
                onClick={handleStartRecording}
                className="px-2.5 py-1 bg-[#1a1a1a] hover:bg-[#262626] text-blue-400 border border-[#333333] rounded text-xs font-mono flex items-center space-x-1 transition-colors"
                title="Record instant encrypted audio thought"
              >
                <Mic className="w-3 h-3" />
                <span>Record</span>
              </button>
            )}
          </div>

          {/* Category Filter Chips */}
          <div className="flex items-center space-x-1 overflow-x-auto text-[10px] font-mono pt-1">
            {(['all', 'image', 'pdf', 'audio', 'video'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-2 py-1 rounded transition-colors uppercase border ${
                  filterCategory === cat
                    ? 'bg-[#1e1e1e] text-white border-[#333333] font-semibold'
                    : 'bg-[#121212] text-[#777777] border-[#1e1e1e] hover:text-[#d4d4d4]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Media Items List */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#181818]">
          {filteredFiles.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#555555] font-mono">
              No media documents found in this category.
            </div>
          ) : (
            filteredFiles.map(file => {
              const isSelected = selectedFile?.id === file.id;
              return (
                <div
                  key={file.id}
                  onClick={() => setSelectedFileId(file.id)}
                  className={`p-3 cursor-pointer transition-all ${
                    isSelected ? 'bg-[#141414] border-l-2 border-blue-500' : 'hover:bg-[#0f0f0f]'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <div className="w-8 h-8 rounded bg-[#141414] border border-[#222222] flex items-center justify-center text-slate-300 flex-shrink-0">
                      {file.category === 'image' && <ImageIcon className="w-4 h-4 text-blue-400" />}
                      {file.category === 'pdf' && <FileText className="w-4 h-4 text-rose-400" />}
                      {file.category === 'audio' && <Music className="w-4 h-4 text-amber-400" />}
                      {file.category === 'video' && <Video className="w-4 h-4 text-sky-400" />}
                      {file.category === 'document' && <FileText className="w-4 h-4 text-[#888888]" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-semibold text-[#d4d4d4] truncate">{file.name}</h4>
                      <div className="flex items-center space-x-2 text-[10px] font-mono text-[#666666] mt-0.5">
                        <span>{(file.size / 1024).toFixed(1)} KB</span>
                        <span>•</span>
                        <span>{new Date(file.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Main Sandbox Previewer */}
      {selectedFile ? (
        <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden">
          {/* Viewer Top Action Bar */}
          <div className="px-4 py-2.5 border-b border-[#1e1e1e] bg-[#0a0a0a] flex items-center justify-between">
            <div className="flex items-center space-x-2 truncate">
              <span className="text-xs font-semibold text-[#f0f0f0] font-mono truncate">
                {selectedFile.name}
              </span>
              {selectedFile.exifStripped && (
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/60">
                  EXIF CLEAN
                </span>
              )}
            </div>

            <div className="flex items-center space-x-2">
              {selectedFile.category === 'image' && (
                <>
                  <button
                    onClick={() => setZoomLevel(z => Math.min(3, z + 0.25))}
                    className="p-1 rounded bg-[#141414] border border-[#262626] text-[#888888] hover:text-[#d4d4d4]"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setZoomLevel(z => Math.max(0.5, z - 0.25))}
                    className="p-1 rounded bg-[#141414] border border-[#262626] text-[#888888] hover:text-[#d4d4d4]"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setRotation(r => (r + 90) % 360)}
                    className="p-1 rounded bg-[#141414] border border-[#262626] text-[#888888] hover:text-[#d4d4d4]"
                    title="Rotate Image"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={handleCleanExif}
                    className="flex items-center space-x-1 px-2 py-1 bg-[#141414] border border-[#262626] text-emerald-400 rounded text-xs font-mono hover:bg-[#1a1a1a] transition-colors"
                    title="Strip all camera & location EXIF metadata from this photo"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Clean EXIF</span>
                  </button>
                </>
              )}

              <button
                onClick={() => handleDownload(selectedFile)}
                className="p-1.5 rounded bg-[#141414] border border-[#262626] text-[#d4d4d4] hover:text-white transition-colors"
                title="Download Decrypted File"
              >
                <Download className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => handleDeleteFile(selectedFile.id)}
                className="p-1.5 rounded bg-[#1a1a1a] border border-[#262626] text-red-400 hover:text-red-300 transition-colors"
                title="Shred from Vault"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {exifCleanedNotice && (
            <div className="bg-emerald-950/70 border-b border-emerald-800 text-emerald-300 text-xs px-4 py-1.5 font-mono flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4" />
              <span>EXIF metadata headers, GPS tags, and hardware serials wiped cleanly from memory.</span>
            </div>
          )}

          {/* Media Player Canvas */}
          <div className="flex-1 p-6 flex items-center justify-center overflow-auto bg-[#050505]">
            {/* Image Preview */}
            {selectedFile.category === 'image' && (
              <div className="max-w-full max-h-full flex items-center justify-center p-4">
                <img
                  src={selectedFile.dataUrl}
                  alt={selectedFile.name}
                  style={{
                    transform: `scale(${zoomLevel}) rotate(${rotation}deg)`,
                    transition: 'transform 0.2s ease-out',
                  }}
                  className="max-h-[60vh] object-contain rounded-lg border border-[#1e1e1e] shadow-2xl"
                />
              </div>
            )}

            {/* PDF Viewer */}
            {selectedFile.category === 'pdf' && (
              <div className="w-full h-full flex flex-col bg-[#0a0a0a] rounded-lg border border-[#1e1e1e] overflow-hidden">
                <iframe
                  src={selectedFile.dataUrl}
                  title={selectedFile.name}
                  className="w-full h-full border-none"
                />
              </div>
            )}

            {/* Audio Player */}
            {selectedFile.category === 'audio' && (
              <div className="w-full max-w-md bg-[#0a0a0a] border border-[#1e1e1e] rounded-2xl p-6 shadow-2xl text-center">
                <div className="w-16 h-16 rounded-full bg-[#141414] border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto mb-4">
                  <Music className="w-8 h-8" />
                </div>
                <h3 className="text-sm font-semibold text-[#f0f0f0] font-mono mb-1 truncate">
                  {selectedFile.name}
                </h3>
                <p className="text-xs text-[#777777] font-mono mb-5">
                  {(selectedFile.size / 1024).toFixed(1)} KB • Encrypted Voice Thought
                </p>

                <audio controls src={selectedFile.dataUrl} className="w-full rounded-lg" />
              </div>
            )}

            {/* Video Player */}
            {selectedFile.category === 'video' && (
              <div className="max-w-4xl max-h-[70vh] flex items-center justify-center">
                <video
                  controls
                  src={selectedFile.dataUrl}
                  className="max-h-[65vh] w-auto rounded-lg border border-[#1e1e1e] shadow-2xl"
                />
              </div>
            )}

            {/* Document / Text / Fallback */}
            {selectedFile.category === 'document' && (
              <div className="w-full h-full bg-[#0a0a0a] border border-[#1e1e1e] rounded-lg p-4 font-mono text-xs text-[#d4d4d4] overflow-auto">
                <pre className="whitespace-pre-wrap leading-relaxed">
                  {selectedFile.dataUrl.startsWith('data:text')
                    ? atob(selectedFile.dataUrl.split(',')[1] || '')
                    : 'Encrypted document binary stream.'}
                </pre>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-[#555555] font-mono text-xs">
          <Sparkles className="w-10 h-10 mb-2 stroke-[1.2]" />
          <span>Select or record a media document to preview.</span>
        </div>
      )}
    </div>
  );
};
