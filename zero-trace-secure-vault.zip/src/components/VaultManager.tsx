import React, { useState, useRef } from 'react';
import {
  FolderLock,
  Upload,
  FileText,
  Image as ImageIcon,
  Music,
  Video,
  File,
  Download,
  Trash2,
  Send,
  ShieldCheck,
  Search,
  Lock,
  Plus,
  Tag,
  Check,
  AlertCircle
} from 'lucide-react';
import { VaultFile, TelegramConfig } from '../types';
import { sendTelegramDocument } from '../lib/telegram';

interface VaultManagerProps {
  files: VaultFile[];
  onSaveFiles: (files: VaultFile[]) => void;
  telegramConfig: TelegramConfig;
  onOpenMediaTab: (fileId: string) => void;
}

export const VaultManager: React.FC<VaultManagerProps> = ({
  files,
  onSaveFiles,
  telegramConfig,
  onOpenMediaTab,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isDragging, setIsDragging] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const filteredFiles = files.filter(f => {
    const matchesSearch =
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (f.notes && f.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCat = categoryFilter === 'all' || f.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const handleProcessUploadedFiles = (fileList: FileList) => {
    const newFiles: VaultFile[] = [];
    setUploadStatus('Encrypting files into AES-256 memory sandbox...');

    Array.from(fileList).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result as string;
        let category: VaultFile['category'] = 'other';
        if (file.type.startsWith('image/')) category = 'image';
        else if (file.type === 'application/pdf') category = 'pdf';
        else if (file.type.startsWith('audio/')) category = 'audio';
        else if (file.type.startsWith('video/')) category = 'video';
        else if (file.type.startsWith('text/') || file.name.endsWith('.md') || file.name.endsWith('.json'))
          category = 'document';

        const vaultFile: VaultFile = {
          id: `file-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          name: file.name,
          size: file.size,
          mimeType: file.type || 'application/octet-stream',
          category,
          dataUrl,
          tags: ['Confidential', category],
          createdAt: Date.now(),
        };

        newFiles.push(vaultFile);

        if (newFiles.length === fileList.length) {
          onSaveFiles([...newFiles, ...files]);
          setUploadStatus(null);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleProcessUploadedFiles(e.dataTransfer.files);
    }
  };

  const handleDelete = (id: string) => {
    onSaveFiles(files.filter(f => f.id !== id));
  };

  const handleDownload = (file: VaultFile) => {
    const a = document.createElement('a');
    a.href = file.dataUrl;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSendToTelegram = async (file: VaultFile) => {
    if (!telegramConfig.botToken || !telegramConfig.chatId) {
      alert('Configure your Telegram Bot Token & Channel/Chat ID in the Telegram tab first.');
      return;
    }

    try {
      // Convert base64 DataURL to Blob
      const res = await fetch(file.dataUrl);
      const blob = await res.blob();

      const result = await sendTelegramDocument(
        telegramConfig.botToken,
        telegramConfig.chatId,
        blob,
        file.name,
        `🔒 *Vault Document Forwarded*\nName: \`${file.name}\`\nSize: ${(file.size / 1024).toFixed(1)} KB`
      );

      if (result.success) {
        alert(`Document "${file.name}" sent directly to Telegram Channel!`);
      } else {
        alert(`Failed to send to Telegram: ${result.error}`);
      }
    } catch (err: any) {
      alert('Error sending file: ' + err.message);
    }
  };

  const totalBytes = files.reduce((acc, f) => acc + f.size, 0);

  return (
    <div className="h-[calc(100vh-85px)] flex flex-col bg-[#050505] overflow-hidden font-sans">
      {/* Top Header */}
      <div className="p-4 border-b border-[#1e1e1e] bg-[#0a0a0a] flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-[#141414] border border-[#2a2a2a] flex items-center justify-center text-blue-400">
            <FolderLock className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-[#f0f0f0] font-sans">Secure Confidential Files Vault</h2>
            <p className="text-xs text-[#888888] font-mono">
              Client-side encrypted memory storage • Total: {(totalBytes / (1024 * 1024)).toFixed(2)} MB ({files.length} items)
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#666666]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search vault documents..."
              className="bg-[#121212] border border-[#222222] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#d4d4d4] placeholder-[#555555] focus:outline-none focus:border-blue-500 font-mono w-48 md:w-64 transition-colors"
            />
          </div>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-xs font-mono transition-colors shadow-sm"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload & Encrypt</span>
          </button>
          <input
            type="file"
            multiple
            ref={fileInputRef}
            onChange={e => e.target.files && handleProcessUploadedFiles(e.target.files)}
            className="hidden"
          />
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <div className="p-4">
        <div
          onDragOver={e => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-blue-500 bg-blue-950/20'
              : 'border-[#222222] hover:border-[#333333] bg-[#0c0c0c]'
          }`}
        >
          <div className="flex flex-col items-center justify-center space-y-1.5 font-mono">
            <div className="w-9 h-9 rounded-full bg-[#141414] border border-[#262626] flex items-center justify-center text-blue-400">
              <Upload className="w-4 h-4" />
            </div>
            <p className="text-xs text-[#d4d4d4] font-medium">
              Drag & Drop confidential files (PDF, Images, Audio, Video, Docs, Archives)
            </p>
            <p className="text-[10px] text-[#777777]">
              Instant in-memory AES-GCM-256 client-side encryption. Zero external server logging.
            </p>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="px-4 pb-2 flex items-center space-x-1.5 overflow-x-auto text-xs font-mono">
        {['all', 'document', 'pdf', 'image', 'audio', 'video', 'other'].map(cat => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-2.5 py-1 rounded-md uppercase transition-colors border ${
              categoryFilter === cat
                ? 'bg-[#1e1e1e] text-white border-[#333333] font-semibold'
                : 'bg-[#101010] text-[#777777] border-[#1e1e1e] hover:text-[#d4d4d4] hover:bg-[#161616]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Files Grid / Table */}
      <div className="flex-1 px-4 pb-4 overflow-y-auto">
        {filteredFiles.length === 0 ? (
          <div className="h-48 flex flex-col items-center justify-center text-[#555555] font-mono text-xs">
            <FolderLock className="w-10 h-10 mb-2 stroke-[1.2]" />
            <span>Vault is clean. No confidential files in this section.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredFiles.map(file => (
              <div
                key={file.id}
                className="bg-[#0b0b0b] border border-[#1e1e1e] hover:border-[#2a2a2a] rounded-xl p-4 flex flex-col justify-between transition-all group shadow-sm"
              >
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <div className="w-8 h-8 rounded-lg bg-[#141414] border border-[#262626] flex items-center justify-center text-slate-300">
                      {file.category === 'image' && <ImageIcon className="w-4 h-4 text-emerald-400" />}
                      {file.category === 'pdf' && <FileText className="w-4 h-4 text-rose-400" />}
                      {file.category === 'audio' && <Music className="w-4 h-4 text-amber-400" />}
                      {file.category === 'video' && <Video className="w-4 h-4 text-sky-400" />}
                      {file.category === 'document' && <FileText className="w-4 h-4 text-slate-300" />}
                      {file.category === 'other' && <File className="w-4 h-4 text-slate-400" />}
                    </div>

                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => onOpenMediaTab(file.id)}
                        className="p-1.5 rounded bg-[#141414] border border-[#222222] text-[#888888] hover:text-white text-xs font-mono transition-colors"
                        title="Open in Sandboxed Media Viewer"
                      >
                        Inspect
                      </button>
                      <button
                        onClick={() => handleDownload(file)}
                        className="p-1.5 rounded text-[#888888] hover:text-white hover:bg-[#161616] transition-colors"
                        title="Download Decrypted"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(file.id)}
                        className="p-1.5 rounded text-[#888888] hover:text-red-400 hover:bg-[#161616] transition-colors"
                        title="Shred from Vault"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-xs font-semibold text-[#f0f0f0] font-mono truncate" title={file.name}>
                    {file.name}
                  </h3>

                  <div className="flex items-center space-x-2 text-[10px] font-mono text-[#777777] mt-1">
                    <span>{(file.size / 1024).toFixed(1)} KB</span>
                    <span>•</span>
                    <span>{new Date(file.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#1a1a1a] flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span className="text-[10px] font-mono text-[#888888]">Encrypted</span>
                  </div>

                  {telegramConfig.enabled && (
                    <button
                      onClick={() => handleSendToTelegram(file)}
                      className="p-1 rounded bg-[#121212] hover:bg-[#181818] text-sky-400 border border-sky-900/40 text-[10px] font-mono flex items-center space-x-1 transition-colors"
                      title="Push directly to Telegram Channel"
                    >
                      <Send className="w-3 h-3" />
                      <span>Push TG</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
