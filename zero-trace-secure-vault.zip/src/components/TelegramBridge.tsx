import React, { useState } from 'react';
import {
  Send,
  Shield,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Lock,
  Upload,
  Radio,
  FileCheck,
  Server
} from 'lucide-react';
import { TelegramConfig, VaultFile, NoteItem, JournalEntry, LinkItem, CodeFile } from '../types';
import { testTelegramConnection, pushEncryptedBackupToTelegram, sendTelegramMessage } from '../lib/telegram';
import { getRawEncryptedVault, purgeAllTraces } from '../lib/storage';

interface TelegramBridgeProps {
  config: TelegramConfig;
  onSaveConfig: (cfg: TelegramConfig) => void;
  stats: {
    notesCount: number;
    filesCount: number;
    journalCount: number;
    linksCount: number;
    codeCount: number;
  };
}

export const TelegramBridge: React.FC<TelegramBridgeProps> = ({
  config,
  onSaveConfig,
  stats,
}) => {
  const [botToken, setBotToken] = useState(config.botToken || '');
  const [chatId, setChatId] = useState(config.chatId || '');
  const [autoSync, setAutoSync] = useState(config.autoSync || false);
  const [scrubAfterPush, setScrubAfterPush] = useState(config.scrubAfterPush || false);

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; msg: string } | null>(null);
  const [pushing, setPushing] = useState(false);
  const [pushResult, setPushResult] = useState<{ success: boolean; msg: string } | null>(null);

  const handleTestConnection = async () => {
    if (!botToken.trim() || !chatId.trim()) {
      setTestResult({ success: false, msg: 'Please provide both Bot Token and Chat ID.' });
      return;
    }
    setTesting(true);
    setTestResult(null);

    const result = await testTelegramConnection(botToken, chatId);
    setTesting(false);

    if (result.success) {
      setTestResult({
        success: true,
        msg: `Connected to Bot @${result.botUsername} (${result.botName}) in ${result.chatTitle}`,
      });
      onSaveConfig({
        ...config,
        botToken: botToken.trim(),
        chatId: chatId.trim(),
        enabled: true,
        lastStatus: `Connected (@${result.botUsername})`,
      });
    } else {
      setTestResult({
        success: false,
        msg: result.error || 'Connection failed.',
      });
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig({
      ...config,
      botToken: botToken.trim(),
      chatId: chatId.trim(),
      enabled: !!(botToken.trim() && chatId.trim()),
      autoSync,
      scrubAfterPush,
    });
  };

  const handlePushEncryptedVault = async () => {
    if (!botToken.trim() || !chatId.trim()) {
      alert('Please configure your Telegram Bot Token & Channel/Chat ID first.');
      return;
    }

    setPushing(true);
    setPushResult(null);

    try {
      const rawEncryptedPayload = getRawEncryptedVault();
      if (!rawEncryptedPayload) {
        throw new Error('No encrypted vault payload found to push.');
      }

      const res = await pushEncryptedBackupToTelegram(
        botToken,
        chatId,
        rawEncryptedPayload,
        stats
      );

      if (res.success) {
        const syncTime = Date.now();
        onSaveConfig({
          ...config,
          lastSyncTime: syncTime,
          lastStatus: `Backup Synced (${new Date(syncTime).toLocaleTimeString()})`,
        });

        if (scrubAfterPush) {
          setPushResult({
            success: true,
            msg: 'Vault dispatched to Telegram Channel! Executing local zero-trace purge in 3 seconds...',
          });
          setTimeout(() => {
            purgeAllTraces();
            window.location.reload();
          }, 3000);
        } else {
          setPushResult({
            success: true,
            msg: 'Encrypted vault backup successfully transmitted to Telegram!',
          });
        }
      } else {
        setPushResult({
          success: false,
          msg: res.error || 'Upload to Telegram failed.',
        });
      }
    } catch (err: any) {
      setPushResult({ success: false, msg: err.message || 'Push failed.' });
    } finally {
      setPushing(false);
    }
  };

  return (
    <div className="h-[calc(100vh-85px)] flex flex-col bg-[#050505] overflow-hidden font-sans">
      {/* Top Header */}
      <div className="p-4 border-b border-[#1e1e1e] bg-[#0a0a0a] flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-[#141414] border border-[#262626] flex items-center justify-center text-blue-400">
            <Send className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-[#f0f0f0] font-sans">Telegram Exfiltration & Remote Storage Server</h2>
            <p className="text-xs text-[#888888] font-mono">
              Zero-knowledge encrypted cloud dispatch with auto-purge local traces option
            </p>
          </div>
        </div>
      </div>

      {/* Main Form & Push Controls */}
      <div className="flex-1 p-6 overflow-y-auto max-w-4xl mx-auto w-full space-y-6">
        {/* Connection Setup Card */}
        <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4 font-mono text-xs">
          <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
            <Server className="w-4 h-4 text-blue-400" />
            <span>Telegram Bot API Configuration</span>
          </h3>
          <p className="text-[#888888] font-sans leading-relaxed">
            Create a private Telegram bot via <code className="text-blue-400 font-mono">@BotFather</code> and a private Channel or Chat to act as your remote zero-knowledge encrypted vault storage.
          </p>

          <form onSubmit={handleSaveSettings} className="space-y-4 pt-2">
            <div>
              <label className="block text-[#d4d4d4] mb-1">Telegram Bot Token:</label>
              <input
                type="password"
                value={botToken}
                onChange={e => setBotToken(e.target.value)}
                placeholder="123456789:ABCdefGhIJKlmNoPQRstuVWXyz..."
                className="w-full bg-[#121212] border border-[#222222] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-[#d4d4d4] mb-1">Target Channel / Chat ID:</label>
              <input
                type="text"
                value={chatId}
                onChange={e => setChatId(e.target.value)}
                placeholder="-1001234567890 or @MyPrivateVaultChannel"
                className="w-full bg-[#121212] border border-[#222222] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            <div className="space-y-2 pt-1">
              <label className="flex items-center space-x-2 cursor-pointer text-[#d4d4d4]">
                <input
                  type="checkbox"
                  checked={scrubAfterPush}
                  onChange={e => setScrubAfterPush(e.target.checked)}
                  className="rounded bg-[#141414] border-[#262626] text-blue-500"
                />
                <span className="font-semibold text-amber-400">
                  Scrub & Disperse: Immediately wipe local storage & memory traces upon successful push
                </span>
              </label>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                type="button"
                onClick={handleTestConnection}
                disabled={testing}
                className="py-2 px-4 bg-[#141414] hover:bg-[#1e1e1e] border border-blue-800/40 text-blue-400 font-semibold rounded transition-colors flex items-center space-x-2"
              >
                {testing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Radio className="w-3.5 h-3.5" />}
                <span>Test Handshake</span>
              </button>

              <button
                type="submit"
                className="py-2 px-4 bg-[#141414] hover:bg-[#1e1e1e] border border-[#262626] text-[#d4d4d4] font-semibold rounded transition-colors"
              >
                Save Settings
              </button>
            </div>
          </form>

          {testResult && (
            <div
              className={`p-3 rounded-lg border text-xs flex items-start space-x-2 ${
                testResult.success
                  ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-300'
                  : 'bg-red-950/40 border-red-700/60 text-red-300'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              )}
              <span>{testResult.msg}</span>
            </div>
          )}
        </div>

        {/* Dispatch Action Box */}
        <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4 font-mono text-xs">
          <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
            <Upload className="w-4 h-4 text-blue-400" />
            <span>Exfiltrate / Push Encrypted Backup</span>
          </h3>

          <div className="p-3 bg-[#121212] border border-[#222222] rounded text-[#d4d4d4] space-y-1">
            <div><strong>Vault Stats:</strong> {stats.notesCount} Notes, {stats.journalCount} Journal logs, {stats.filesCount} Files, {stats.linksCount} Links, {stats.codeCount} Code files</div>
            <div><strong>Encryption Status:</strong> AES-GCM-256 Armed</div>
            <div><strong>Last Remote Sync:</strong> {config.lastSyncTime ? new Date(config.lastSyncTime).toLocaleString() : 'Never'}</div>
          </div>

          <button
            onClick={handlePushEncryptedVault}
            disabled={pushing || !botToken || !chatId}
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-sm transition-all duration-150 flex items-center justify-center space-x-2 shadow-lg disabled:opacity-40"
          >
            {pushing ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>{scrubAfterPush ? 'Push to Telegram & Scrub All Local Traces' : 'Push Encrypted Backup to Telegram'}</span>
              </>
            )}
          </button>

          {pushResult && (
            <div
              className={`p-3 rounded-lg border text-xs flex items-start space-x-2 ${
                pushResult.success
                  ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-300'
                  : 'bg-red-950/40 border-red-700/60 text-red-300'
              }`}
            >
              {pushResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              )}
              <span>{pushResult.msg}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
