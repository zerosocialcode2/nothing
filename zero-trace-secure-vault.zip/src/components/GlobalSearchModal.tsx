import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  FileText,
  BookOpen,
  Code2,
  Bookmark,
  FolderLock,
  X,
  ArrowRight
} from 'lucide-react';
import { ViewMode, SearchResultItem, NoteItem, JournalEntry, VaultFile, CodeFile, LinkItem } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: ViewMode, itemId?: string) => void;
  notes: NoteItem[];
  journal: JournalEntry[];
  files: VaultFile[];
  codeFiles: CodeFile[];
  links: LinkItem[];
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  notes,
  journal,
  files,
  codeFiles,
  links,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const searchResults: SearchResultItem[] = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    const results: SearchResultItem[] = [];

    // Notes
    notes.forEach(n => {
      if (n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q) || n.tags.some(t => t.toLowerCase().includes(q))) {
        results.push({
          id: n.id,
          title: n.title,
          snippet: n.content.substring(0, 100),
          type: 'note',
          category: 'Notes',
          timestamp: n.updatedAt,
          targetView: 'notes',
        });
      }
    });

    // Journal
    journal.forEach(j => {
      if (j.title.toLowerCase().includes(q) || j.content.toLowerCase().includes(q) || j.securityAssessment.toLowerCase().includes(q)) {
        results.push({
          id: j.id,
          title: j.title,
          snippet: j.content.substring(0, 100),
          type: 'journal',
          category: 'Journal',
          timestamp: j.timestamp,
          targetView: 'journal',
        });
      }
    });

    // Vault Files
    files.forEach(f => {
      if (f.name.toLowerCase().includes(q) || f.tags.some(t => t.toLowerCase().includes(q))) {
        results.push({
          id: f.id,
          title: f.name,
          snippet: `${(f.size / 1024).toFixed(1)} KB • ${f.category}`,
          type: 'file',
          category: 'Files',
          timestamp: f.createdAt,
          targetView: 'vault',
        });
      }
    });

    // Code Files
    codeFiles.forEach(c => {
      if (c.name.toLowerCase().includes(q) || c.content.toLowerCase().includes(q) || c.path.toLowerCase().includes(q)) {
        results.push({
          id: c.id,
          title: c.name,
          snippet: c.content.substring(0, 100),
          type: 'code',
          category: 'Code',
          timestamp: c.updatedAt,
          targetView: 'code',
        });
      }
    });

    // Links
    links.forEach(l => {
      if (l.title.toLowerCase().includes(q) || l.url.toLowerCase().includes(q) || (l.description && l.description.toLowerCase().includes(q))) {
        results.push({
          id: l.id,
          title: l.title,
          snippet: l.url,
          type: 'link',
          category: 'Links',
          timestamp: l.createdAt,
          targetView: 'links',
        });
      }
    });

    return results;
  }, [query, notes, journal, files, codeFiles, links]);

  if (!isOpen) return null;

  const getTypeIcon = (type: SearchResultItem['type']) => {
    switch (type) {
      case 'note': return <FileText className="w-4 h-4 text-blue-400" />;
      case 'journal': return <BookOpen className="w-4 h-4 text-amber-400" />;
      case 'file': return <FolderLock className="w-4 h-4 text-rose-400" />;
      case 'code': return <Code2 className="w-4 h-4 text-sky-400" />;
      case 'link': return <Bookmark className="w-4 h-4 text-purple-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-start justify-center pt-20 p-4 backdrop-blur-sm font-sans">
      <div className="w-full max-w-2xl bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl shadow-2xl overflow-hidden flex flex-col font-mono">
        {/* Search Input Bar */}
        <div className="p-3 border-b border-[#1e1e1e] flex items-center space-x-3 bg-[#121212]">
          <Search className="w-4 h-4 text-[#888888] flex-shrink-0" />
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Universal Encrypted Database Search (Notes, Journal, Code, Links, Files)..."
            className="flex-1 bg-transparent text-sm text-[#f0f0f0] placeholder-[#666666] focus:outline-none"
            autoFocus
          />
          <button onClick={onClose} className="text-[#888888] hover:text-[#d4d4d4]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto divide-y divide-[#181818] p-2">
          {query.trim() === '' ? (
            <div className="p-8 text-center text-xs text-[#555555]">
              Type to search across all decrypted in-memory vault assets...
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-8 text-center text-xs text-[#555555]">
              No confidential entries matching "{query}"
            </div>
          ) : (
            searchResults.map(item => (
              <div
                key={item.id}
                onClick={() => {
                  onNavigate(item.targetView, item.id);
                  onClose();
                }}
                className="p-3 rounded-lg hover:bg-[#141414] cursor-pointer flex items-center justify-between transition-colors group"
              >
                <div className="flex items-center space-x-3 truncate">
                  <div className="w-8 h-8 rounded bg-[#141414] border border-[#222222] flex items-center justify-center flex-shrink-0">
                    {getTypeIcon(item.type)}
                  </div>
                  <div className="truncate">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-semibold text-[#d4d4d4] truncate">{item.title}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#1e1e1e] text-[#888888] uppercase border border-[#262626]">
                        {item.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#888888] truncate mt-0.5 font-sans">
                      {item.snippet}
                    </p>
                  </div>
                </div>

                <ArrowRight className="w-3.5 h-3.5 text-[#555555] group-hover:text-blue-400 transition-colors flex-shrink-0 ml-2" />
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 border-t border-[#1e1e1e] bg-[#080808] text-[10px] text-[#666666] flex items-center justify-between">
          <span>{searchResults.length} encrypted matches found</span>
          <span>Esc to dismiss</span>
        </div>
      </div>
    </div>
  );
};
