import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Plus,
  ShieldAlert,
  Calendar,
  Lock,
  Hash,
  AlertTriangle,
  Smile,
  Search,
  CheckCircle2,
  Trash2,
  Share2,
  Tag
} from 'lucide-react';
import { JournalEntry } from '../types';
import { calculateSha256 } from '../lib/crypto';

interface JournalViewProps {
  entries: JournalEntry[];
  onSaveEntries: (updated: JournalEntry[]) => void;
}

export const JournalView: React.FC<JournalViewProps> = ({ entries, onSaveEntries }) => {
  const [selectedId, setSelectedId] = useState<string>(entries[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [isVerifyingHashes, setIsVerifyingHashes] = useState(false);
  const [hashIntegrityVerified, setHashIntegrityVerified] = useState<boolean | null>(null);

  const activeEntry = useMemo(() => {
    return entries.find(e => e.id === selectedId) || entries[0] || null;
  }, [entries, selectedId]);

  const filteredEntries = useMemo(() => {
    return entries
      .filter(e => {
        return (
          e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.securityAssessment.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
        );
      })
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [entries, searchQuery]);

  const handleCreateEntry = async () => {
    const prevHash = entries[0]?.hash || '0000000000000000000000000000000000000000000000000000000000000000';
    const now = Date.now();
    const title = `Surveillance Log #${entries.length + 1}`;
    const initialContent = `Operational notes & thoughts...\n\n- Observations:\n- Potential exposure vectors:\n- Defensive counter-measures:`;
    
    // Calculate initial hash
    const rawData = `${prevHash}:${title}:${initialContent}:${now}`;
    const hash = await calculateSha256(rawData);

    const newEntry: JournalEntry = {
      id: `journal-${now}-${Math.random().toString(36).substring(2, 6)}`,
      title,
      content: initialContent,
      date: new Date().toISOString().split('T')[0],
      timestamp: now,
      paranoiaLevel: 3,
      mood: 'vigilant',
      securityAssessment: 'Guarded: Normal threat baseline maintained.',
      hash,
      previousHash: prevHash,
      tags: ['DailyLog', 'OpSec'],
    };

    const updated = [newEntry, ...entries];
    onSaveEntries(updated);
    setSelectedId(newEntry.id);
  };

  const handleUpdateActiveEntry = async (updates: Partial<JournalEntry>) => {
    if (!activeEntry) return;
    const merged = { ...activeEntry, ...updates };

    // Recompute tamper-evident cryptographic hash
    const rawData = `${merged.previousHash}:${merged.title}:${merged.content}:${merged.timestamp}`;
    const newHash = await calculateSha256(rawData);
    merged.hash = newHash;

    const updated = entries.map(e => (e.id === activeEntry.id ? merged : e));
    onSaveEntries(updated);
  };

  const handleDeleteEntry = (id: string) => {
    const updated = entries.filter(e => e.id !== id);
    onSaveEntries(updated);
    if (selectedId === id) {
      setSelectedId(updated[0]?.id || '');
    }
  };

  // Verify full blockchain-style Merkle hash integrity
  const handleVerifyChainIntegrity = async () => {
    setIsVerifyingHashes(true);
    let allValid = true;
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      const rawData = `${e.previousHash}:${e.title}:${e.content}:${e.timestamp}`;
      const expectedHash = await calculateSha256(rawData);
      if (expectedHash !== e.hash) {
        allValid = false;
        break;
      }
    }
    setTimeout(() => {
      setHashIntegrityVerified(allValid);
      setIsVerifyingHashes(false);
    }, 400);
  };

  const getParanoiaColor = (level: number) => {
    switch (level) {
      case 1:
        return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60';
      case 2:
        return 'text-sky-400 bg-sky-950/40 border-sky-800/60';
      case 3:
        return 'text-amber-400 bg-amber-950/40 border-amber-800/60';
      case 4:
        return 'text-orange-400 bg-orange-950/40 border-orange-800/60';
      case 5:
        return 'text-red-400 bg-red-950/40 border-red-800/60 animate-pulse';
      default:
        return 'text-slate-400 bg-slate-800 border-slate-700';
    }
  };

  const getParanoiaLabel = (level: number) => {
    switch (level) {
      case 1: return 'Level 1: Minimal Alert (Relaxed)';
      case 2: return 'Level 2: Guarded (Standard)';
      case 3: return 'Level 3: Elevated (Vigilant)';
      case 4: return 'Level 4: High Alert (Imminent Watch)';
      case 5: return 'Level 5: DEFCON 1 Extreme Threat';
      default: return 'Level 3';
    }
  };

  return (
    <div className="h-[calc(100vh-85px)] flex bg-[#050505] overflow-hidden font-sans">
      {/* Sidebar Journal Entries */}
      <div className="w-84 border-r border-[#1e1e1e] flex flex-col bg-[#0a0a0a] flex-shrink-0">
        {/* Header & Search */}
        <div className="p-3 border-b border-[#1e1e1e] space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-mono font-semibold uppercase tracking-wider text-[#888888] flex items-center space-x-1.5">
              <BookOpen className="w-3.5 h-3.5 text-blue-400" />
              <span>Paranoid Journal ({entries.length})</span>
            </h2>
            <button
              onClick={handleCreateEntry}
              className="p-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-lg text-xs flex items-center space-x-1 transition-colors font-mono"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log</span>
            </button>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#666666]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search thoughts & logs..."
              className="w-full bg-[#121212] border border-[#222222] rounded-md pl-8 pr-3 py-1.5 text-xs text-[#d4d4d4] placeholder-[#555555] focus:outline-none focus:border-blue-500 font-mono transition-colors"
            />
          </div>

          {/* Hash Chain Verifier Banner */}
          <button
            onClick={handleVerifyChainIntegrity}
            disabled={isVerifyingHashes}
            className="w-full py-1.5 px-2 rounded bg-[#121212] border border-[#222222] text-[10px] font-mono text-[#888888] hover:text-white flex items-center justify-between transition-colors"
          >
            <span className="flex items-center space-x-1">
              <Hash className="w-3 h-3 text-blue-400" />
              <span>SHA-256 Tamper Audit</span>
            </span>
            {hashIntegrityVerified === true && (
              <span className="text-emerald-400 flex items-center space-x-1">
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span>Verified</span>
              </span>
            )}
            {hashIntegrityVerified === false && (
              <span className="text-red-400 flex items-center space-x-1">
                <AlertTriangle className="w-2.5 h-2.5" />
                <span>Tampered!</span>
              </span>
            )}
            {hashIntegrityVerified === null && <span>Run Check</span>}
          </button>
        </div>

        {/* Entries List */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#1e1e1e]/60">
          {filteredEntries.length === 0 ? (
            <div className="p-6 text-center text-xs text-[#555555] font-mono">
              No journal logs found. Record your first private thought.
            </div>
          ) : (
            filteredEntries.map(entry => {
              const isSelected = activeEntry?.id === entry.id;
              return (
                <div
                  key={entry.id}
                  onClick={() => setSelectedId(entry.id)}
                  className={`p-3 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#141414] border-l-2 border-blue-500'
                      : 'hover:bg-[#0f0f0f]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono text-[#666666] flex items-center space-x-1">
                      <Calendar className="w-3 h-3" />
                      <span>{entry.date}</span>
                    </span>
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded border uppercase ${getParanoiaColor(
                        entry.paranoiaLevel
                      )}`}
                    >
                      DEFCON {entry.paranoiaLevel}
                    </span>
                  </div>

                  <h3 className="text-xs font-semibold text-[#f0f0f0] truncate font-mono">{entry.title}</h3>

                  <p className="text-[11px] text-[#888888] line-clamp-2 mt-1 font-sans">
                    {entry.content.replace(/[#*`_]/g, '')}
                  </p>

                  <div className="flex items-center justify-between mt-2 text-[9px] font-mono text-[#666666]">
                    <span className="text-[#888888]">Mood: {entry.mood}</span>
                    <span className="truncate max-w-[100px] text-[#555555]">
                      #{entry.hash.substring(0, 8)}...
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Main Journal View */}
      {activeEntry ? (
        <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden">
          {/* Top Metadata Bar */}
          <div className="p-4 border-b border-[#1e1e1e] bg-[#0a0a0a] space-y-3">
            <div className="flex items-center justify-between">
              <input
                type="text"
                value={activeEntry.title}
                onChange={e => handleUpdateActiveEntry({ title: e.target.value })}
                className="text-base font-semibold text-[#f0f0f0] bg-transparent border-none focus:outline-none focus:ring-0 w-2/3 font-mono"
                placeholder="Log Entry Title..."
              />
              <button
                onClick={() => handleDeleteEntry(activeEntry.id)}
                className="p-1.5 bg-red-950/30 border border-red-900/40 text-red-400 hover:text-red-300 rounded text-xs font-mono transition-colors"
                title="Purge Journal Entry"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Paranoia & Threat Assessment Control Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-xs font-mono">
              {/* Paranoia Slider */}
              <div className="bg-[#121212] p-2.5 rounded-lg border border-[#222222]">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[#888888] flex items-center space-x-1">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    <span>Threat / Paranoia:</span>
                  </span>
                  <span className="text-[11px] font-bold text-[#f0f0f0]">
                    {getParanoiaLabel(activeEntry.paranoiaLevel)}
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={activeEntry.paranoiaLevel}
                  onChange={e => handleUpdateActiveEntry({ paranoiaLevel: parseInt(e.target.value) })}
                  className="w-full h-1.5 bg-[#222222] rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              {/* Mood Selector */}
              <div className="bg-[#121212] p-2.5 rounded-lg border border-[#222222]">
                <label className="block text-[#888888] mb-1 flex items-center space-x-1">
                  <Smile className="w-3.5 h-3.5 text-sky-400" />
                  <span>Psychological State:</span>
                </label>
                <select
                  value={activeEntry.mood}
                  onChange={e => handleUpdateActiveEntry({ mood: e.target.value as any })}
                  className="w-full bg-[#0a0a0a] border border-[#262626] text-[#d4d4d4] text-xs rounded px-2 py-1 focus:outline-none focus:border-blue-500"
                >
                  <option value="vigilant">Vigilant / Hyper-Aware</option>
                  <option value="focused">Focused & Resolute</option>
                  <option value="secure">Secure & Sanctuary</option>
                  <option value="concerned">Concerned / Suspicious</option>
                  <option value="isolated">Air-Gapped & Isolated</option>
                </select>
              </div>

              {/* Security Assessment Input */}
              <div className="bg-[#121212] p-2.5 rounded-lg border border-[#222222]">
                <label className="block text-[#888888] mb-1 flex items-center space-x-1">
                  <Lock className="w-3.5 h-3.5 text-blue-400" />
                  <span>Threat Assessment:</span>
                </label>
                <input
                  type="text"
                  value={activeEntry.securityAssessment}
                  onChange={e => handleUpdateActiveEntry({ securityAssessment: e.target.value })}
                  placeholder="e.g. Clean environment, no anomalies"
                  className="w-full bg-[#0a0a0a] border border-[#262626] text-[#d4d4d4] text-xs rounded px-2 py-1 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Journal Main Text Area */}
          <div className="flex-1 p-6 overflow-y-auto">
            <textarea
              value={activeEntry.content}
              onChange={e => handleUpdateActiveEntry({ content: e.target.value })}
              className="w-full h-full bg-transparent text-[#d4d4d4] font-sans text-sm leading-relaxed border-none focus:outline-none resize-none placeholder-[#444444] font-normal"
              placeholder="Record your unfiltered thoughts, observations, suspicious activities, or mental sandbox notes..."
              spellCheck={false}
            />
          </div>

          {/* Cryptographic Tamper Hash Stamp */}
          <div className="px-5 py-2 border-t border-[#1e1e1e] bg-[#080808] flex flex-wrap items-center justify-between text-[10px] font-mono text-[#666666] gap-2">
            <div className="flex items-center space-x-2">
              <span className="text-blue-400">HASH CHAIN:</span>
              <span className="text-[#888888] bg-[#121212] px-2 py-0.5 rounded border border-[#222222]">
                {activeEntry.hash}
              </span>
            </div>
            <span>PREV: {activeEntry.previousHash.substring(0, 16)}...</span>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-[#555555] font-mono text-xs">
          <BookOpen className="w-10 h-10 mb-2 stroke-[1.2]" />
          <span>Select or create a journal entry to record private logs.</span>
        </div>
      )}
    </div>
  );
};
