import React, { useState } from 'react';
import {
  Wrench,
  Key,
  EyeOff,
  FileCheck,
  Activity,
  Shield,
  Copy,
  Check,
  RefreshCw,
  Sliders,
  Upload,
  Download,
  AlertTriangle,
  Lock,
  Unlock,
  Radio
} from 'lucide-react';
import {
  generateSecurePassword,
  hideMessageInImage,
  extractMessageFromImage,
  encryptText,
  decryptText,
  stripImageMetadata
} from '../lib/crypto';

export const ParanoidTools: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'passgen' | 'stego' | 'cipher' | 'metadata' | 'network'>('passgen');

  // Password Generator State
  const [passType, setPassType] = useState<'passphrase' | 'random'>('passphrase');
  const [passLength, setPassLength] = useState(5);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [generatedPass, setGeneratedPass] = useState(() =>
    generateSecurePassword({ type: 'passphrase', length: 5, includeSymbols: true, includeNumbers: true })
  );
  const [copiedPass, setCopiedPass] = useState(false);

  // Steganography State
  const [stegoImage, setStegoImage] = useState<string | null>(null);
  const [stegoSecretText, setStegoSecretText] = useState('');
  const [stegoResultImage, setStegoResultImage] = useState<string | null>(null);
  const [extractedSecret, setExtractedSecret] = useState<string | null>(null);
  const [stegoLoading, setStegoLoading] = useState(false);

  // Text Cipher State
  const [cipherInput, setCipherInput] = useState('');
  const [cipherKey, setCipherKey] = useState('');
  const [cipherOutput, setCipherOutput] = useState('');
  const [cipherMode, setCipherMode] = useState<'encrypt' | 'decrypt'>('encrypt');
  const [cipherError, setCipherError] = useState<string | null>(null);
  const [copiedCipher, setCopiedCipher] = useState(false);

  // Metadata Stripper State
  const [metaInputImage, setMetaInputImage] = useState<string | null>(null);
  const [metaCleanImage, setMetaCleanImage] = useState<string | null>(null);

  // Regenerate Password
  const handleRegenPassword = () => {
    const p = generateSecurePassword({
      type: passType,
      length: passLength,
      includeSymbols,
      includeNumbers,
    });
    setGeneratedPass(p);
  };

  const handleCopyPassword = () => {
    navigator.clipboard.writeText(generatedPass);
    setCopiedPass(true);
    setTimeout(() => setCopiedPass(false), 1500);
  };

  // Stego Hide Handler
  const handleStegoEmbed = async () => {
    if (!stegoImage || !stegoSecretText) return;
    setStegoLoading(true);
    try {
      const result = await hideMessageInImage(stegoImage, stegoSecretText);
      setStegoResultImage(result);
      setExtractedSecret(null);
    } catch (err: any) {
      alert('Steganography error: ' + err.message);
    } finally {
      setStegoLoading(false);
    }
  };

  // Stego Extract Handler
  const handleStegoExtract = async () => {
    if (!stegoImage) return;
    setStegoLoading(true);
    try {
      const extracted = await extractMessageFromImage(stegoImage);
      if (extracted) {
        setExtractedSecret(extracted);
      } else {
        alert('No hidden zero-trace payload found in this image.');
      }
    } catch (err: any) {
      alert('Steganography extraction error: ' + err.message);
    } finally {
      setStegoLoading(false);
    }
  };

  // Text Cipher Run
  const handleRunCipher = async () => {
    setCipherError(null);
    if (!cipherInput || !cipherKey) {
      setCipherError('Both payload text and key passphrase are required.');
      return;
    }

    try {
      if (cipherMode === 'encrypt') {
        const res = await encryptText(cipherInput, cipherKey);
        setCipherOutput(`-----BEGIN ZERO-TRACE CIPHERTEXT-----\n${JSON.stringify(res, null, 2)}\n-----END ZERO-TRACE CIPHERTEXT-----`);
      } else {
        // Decrypt
        let clean = cipherInput.trim();
        if (clean.includes('-----BEGIN ZERO-TRACE CIPHERTEXT-----')) {
          clean = clean
            .replace('-----BEGIN ZERO-TRACE CIPHERTEXT-----', '')
            .replace('-----END ZERO-TRACE CIPHERTEXT-----', '')
            .trim();
        }
        const parsed = JSON.parse(clean);
        const decrypted = await decryptText(parsed.ciphertext, parsed.iv, parsed.salt, cipherKey);
        setCipherOutput(decrypted);
      }
    } catch (err: any) {
      setCipherError('Cipher operation failed: ' + (err.message || 'Key mismatch or corrupted payload'));
    }
  };

  // Metadata Stripper Run
  const handleStripMetadata = async () => {
    if (!metaInputImage) return;
    const clean = await stripImageMetadata(metaInputImage);
    setMetaCleanImage(clean);
  };

  return (
    <div className="h-[calc(100vh-85px)] flex flex-col bg-[#050505] overflow-hidden font-sans">
      {/* Top Navigation */}
      <div className="p-4 border-b border-[#1e1e1e] bg-[#0a0a0a] flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-[#141414] border border-[#262626] flex items-center justify-center text-blue-400">
            <Wrench className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-[#f0f0f0] font-sans">Operational Security Toolkit</h2>
            <p className="text-xs text-[#888888] font-mono">Cryptographic utilities, steganography, & metadata strippers</p>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 overflow-x-auto text-xs font-mono">
          <button
            onClick={() => setActiveTab('passgen')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeTab === 'passgen' ? 'bg-[#141414] text-blue-400 border border-blue-800/40' : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>Pass Generator</span>
          </button>
          <button
            onClick={() => setActiveTab('stego')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeTab === 'stego' ? 'bg-[#141414] text-blue-400 border border-blue-800/40' : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
            }`}
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>Steganography</span>
          </button>
          <button
            onClick={() => setActiveTab('cipher')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeTab === 'cipher' ? 'bg-[#141414] text-blue-400 border border-blue-800/40' : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Text Cipher</span>
          </button>
          <button
            onClick={() => setActiveTab('metadata')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeTab === 'metadata' ? 'bg-[#141414] text-blue-400 border border-blue-800/40' : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>EXIF Sanitizer</span>
          </button>
          <button
            onClick={() => setActiveTab('network')}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center space-x-1.5 ${
              activeTab === 'network' ? 'bg-[#141414] text-blue-400 border border-blue-800/40' : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Threat Monitor</span>
          </button>
        </div>
      </div>

      {/* Main Tool Content Area */}
      <div className="flex-1 p-6 overflow-y-auto max-w-5xl mx-auto w-full">
        {/* 1. PASSWORD GENERATOR */}
        {activeTab === 'passgen' && (
          <div className="space-y-6">
            <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4">
              <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
                <Key className="w-4 h-4 text-blue-400" />
                <span>Cryptographic Diceware & High-Entropy Key Generator</span>
              </h3>

              {/* Password Display Box */}
              <div className="flex items-center space-x-2">
                <div className="flex-1 bg-[#121212] border border-[#222222] rounded-lg p-3.5 text-base text-emerald-400 font-mono select-all overflow-x-auto">
                  {generatedPass}
                </div>
                <button
                  onClick={handleRegenPassword}
                  className="p-3.5 bg-[#141414] hover:bg-[#1e1e1e] border border-[#262626] text-[#d4d4d4] rounded-lg transition-colors"
                  title="Regenerate Key"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                <button
                  onClick={handleCopyPassword}
                  className="p-3.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg transition-colors"
                  title="Copy to Clipboard"
                >
                  {copiedPass ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Controls */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-[#1e1e1e] font-mono text-xs">
                <div>
                  <label className="block text-[#888888] mb-1.5">Key Architecture Type:</label>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => {
                        setPassType('passphrase');
                        setPassLength(5);
                      }}
                      className={`px-3 py-1.5 rounded border transition-colors ${
                        passType === 'passphrase' ? 'bg-blue-950/50 border-blue-700 text-blue-300' : 'bg-[#121212] border-[#222222] text-[#888888]'
                      }`}
                    >
                      Diceware Passphrase
                    </button>
                    <button
                      onClick={() => {
                        setPassType('random');
                        setPassLength(24);
                      }}
                      className={`px-3 py-1.5 rounded border transition-colors ${
                        passType === 'random' ? 'bg-blue-950/50 border-blue-700 text-blue-300' : 'bg-[#121212] border-[#222222] text-[#888888]'
                      }`}
                    >
                      Random Cryptographic String
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[#888888] mb-1.5">
                    {passType === 'passphrase' ? `Word Count (${passLength} words)` : `Length (${passLength} chars)`}:
                  </label>
                  <input
                    type="range"
                    min={passType === 'passphrase' ? 3 : 12}
                    max={passType === 'passphrase' ? 8 : 48}
                    value={passLength}
                    onChange={e => setPassLength(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-[#1e1e1e] rounded appearance-none cursor-pointer accent-blue-500"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-4 pt-2 font-mono text-xs text-[#888888]">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeSymbols}
                    onChange={e => setIncludeSymbols(e.target.checked)}
                    className="rounded bg-[#141414] border-[#262626] text-blue-500"
                  />
                  <span>Include Symbols</span>
                </label>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeNumbers}
                    onChange={e => setIncludeNumbers(e.target.checked)}
                    className="rounded bg-[#141414] border-[#262626] text-blue-500"
                  />
                  <span>Include Random Numbers</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* 2. STEGANOGRAPHY */}
        {activeTab === 'stego' && (
          <div className="space-y-6">
            <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4 font-mono text-xs">
              <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
                <EyeOff className="w-4 h-4 text-blue-400" />
                <span>Image Steganography (RGB Canvas LSB Embedding)</span>
              </h3>
              <p className="text-[#888888] font-sans">
                Hide secret encrypted text imperceptibly inside ordinary PNG/JPG images, or extract hidden messages from existing carriers.
              </p>

              {/* Image Input */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-[#d4d4d4] mb-1.5">1. Select Carrier Image:</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={e => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = () => setStegoImage(reader.result as string);
                        reader.readAsDataURL(file);
                      }
                    }}
                    className="w-full text-xs text-[#888888] file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:bg-[#1e1e1e] file:text-[#d4d4d4]"
                  />

                  {stegoImage && (
                    <div className="mt-3 p-2 bg-[#121212] border border-[#222222] rounded max-h-48 flex items-center justify-center">
                      <img src={stegoImage} alt="Carrier" className="max-h-40 object-contain rounded" />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[#d4d4d4] mb-1.5">2. Secret Text to Hide (or extract):</label>
                  <textarea
                    value={stegoSecretText}
                    onChange={e => setStegoSecretText(e.target.value)}
                    placeholder="Enter confidential instructions, seed phrases, or private thoughts..."
                    className="w-full bg-[#121212] border border-[#222222] rounded p-2.5 text-xs text-[#d4d4d4] h-32 resize-none focus:outline-none focus:border-blue-500"
                  />

                  <div className="flex items-center space-x-2 mt-3">
                    <button
                      onClick={handleStegoEmbed}
                      disabled={stegoLoading || !stegoImage || !stegoSecretText}
                      className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs transition-colors disabled:opacity-40"
                    >
                      Embed Secret into Image
                    </button>
                    <button
                      onClick={handleStegoExtract}
                      disabled={stegoLoading || !stegoImage}
                      className="flex-1 py-2 bg-[#141414] hover:bg-[#1e1e1e] border border-[#262626] text-[#d4d4d4] rounded text-xs transition-colors disabled:opacity-40"
                    >
                      Extract Hidden Payload
                    </button>
                  </div>
                </div>
              </div>

              {/* Stego Result */}
              {stegoResultImage && (
                <div className="mt-4 p-4 rounded-lg bg-[#121212] border border-emerald-800/60 space-y-2">
                  <span className="text-emerald-400 font-semibold block">✓ Secret Embedded Successfully</span>
                  <p className="text-[#888888]">Download this sanitized carrier image to transport your payload invisibly.</p>
                  <a
                    href={stegoResultImage}
                    download="stego-carrier-image.png"
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Stego Image</span>
                  </a>
                </div>
              )}

              {/* Extracted Secret */}
              {extractedSecret && (
                <div className="mt-4 p-4 rounded-lg bg-[#121212] border border-blue-800/60 space-y-2">
                  <span className="text-blue-400 font-semibold block">🔓 Hidden Secret Extracted:</span>
                  <div className="p-3 bg-[#181818] rounded border border-[#262626] text-[#d4d4d4] whitespace-pre-wrap select-all">
                    {extractedSecret}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 3. TEXT CIPHER */}
        {activeTab === 'cipher' && (
          <div className="space-y-6">
            <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4 font-mono text-xs">
              <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
                <Lock className="w-4 h-4 text-blue-400" />
                <span>Zero-Trace Text Cipher Tool (AES-GCM-256)</span>
              </h3>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCipherMode('encrypt')}
                  className={`px-3 py-1.5 rounded border transition-colors ${
                    cipherMode === 'encrypt' ? 'bg-blue-950/50 border-blue-700 text-blue-300' : 'bg-[#121212] border-[#222222] text-[#888888]'
                  }`}
                >
                  Encrypt Text
                </button>
                <button
                  onClick={() => setCipherMode('decrypt')}
                  className={`px-3 py-1.5 rounded border transition-colors ${
                    cipherMode === 'decrypt' ? 'bg-blue-950/50 border-blue-700 text-blue-300' : 'bg-[#121212] border-[#222222] text-[#888888]'
                  }`}
                >
                  Decrypt Armored Block
                </button>
              </div>

              <div>
                <label className="block text-[#d4d4d4] mb-1">
                  Secret Key / Passphrase for Derivation:
                </label>
                <input
                  type="password"
                  value={cipherKey}
                  onChange={e => setCipherKey(e.target.value)}
                  placeholder="Enter custom encryption key..."
                  className="w-full bg-[#121212] border border-[#222222] rounded p-2 text-xs text-[#d4d4d4] focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[#d4d4d4] mb-1">
                  {cipherMode === 'encrypt' ? 'Plaintext to Encrypt:' : 'Armored Ciphertext to Decrypt:'}
                </label>
                <textarea
                  value={cipherInput}
                  onChange={e => setCipherInput(e.target.value)}
                  placeholder={cipherMode === 'encrypt' ? 'Enter sensitive text...' : 'Paste ciphertext block...'}
                  className="w-full bg-[#121212] border border-[#222222] rounded p-2.5 text-xs text-[#d4d4d4] h-28 resize-none focus:outline-none focus:border-blue-500"
                />
              </div>

              <button
                onClick={handleRunCipher}
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs transition-colors"
              >
                Execute {cipherMode === 'encrypt' ? 'AES-256 Encryption' : 'Decryption'}
              </button>

              {cipherError && (
                <div className="p-2.5 rounded bg-red-950/50 border border-red-800 text-red-300 text-xs">
                  {cipherError}
                </div>
              )}

              {cipherOutput && (
                <div className="pt-2 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[#888888] font-semibold">Output Result:</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(cipherOutput);
                        setCopiedCipher(true);
                        setTimeout(() => setCopiedCipher(false), 1500);
                      }}
                      className="text-xs text-blue-400 hover:text-blue-300 flex items-center space-x-1"
                    >
                      {copiedCipher ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <pre className="p-3 bg-[#121212] border border-[#222222] rounded text-[#d4d4d4] whitespace-pre-wrap select-all max-h-40 overflow-auto">
                    {cipherOutput}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 4. METADATA SANITIZER */}
        {activeTab === 'metadata' && (
          <div className="space-y-6">
            <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4 font-mono text-xs">
              <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
                <FileCheck className="w-4 h-4 text-blue-400" />
                <span>EXIF & Metadata Sanitizer</span>
              </h3>
              <p className="text-[#888888] font-sans">
                Wipes GPS latitude/longitude, camera model, lens serials, creation timestamps, and software signatures from images before saving or sharing.
              </p>

              <div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => setMetaInputImage(reader.result as string);
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="w-full text-xs text-[#888888] file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:bg-[#1e1e1e] file:text-[#d4d4d4]"
                />
              </div>

              {metaInputImage && (
                <div className="space-y-3">
                  <button
                    onClick={handleStripMetadata}
                    className="py-2 px-4 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs"
                  >
                    Strip All Metadata
                  </button>

                  {metaCleanImage && (
                    <div className="p-4 rounded-lg bg-[#121212] border border-emerald-800/60 space-y-2">
                      <span className="text-emerald-400 font-semibold block">✓ Image Sanitized Clean</span>
                      <img src={metaCleanImage} alt="Sanitized" className="max-h-48 object-contain rounded" />
                      <a
                        href={metaCleanImage}
                        download="sanitized_image.png"
                        className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs mt-2"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Sanitized Image</span>
                      </a>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 5. THREAT MONITOR */}
        {activeTab === 'network' && (
          <div className="space-y-6">
            <div className="bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-4 font-mono text-xs">
              <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans flex items-center space-x-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <span>Threat & Surveillance Leak Assessment</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3 rounded bg-[#121212] border border-[#1e1e1e]">
                  <span className="text-[#666666] block mb-1">NETWORK EXPOSURE:</span>
                  <span className="text-emerald-400 font-semibold text-sm">
                    {navigator.onLine ? 'Connected (Air-Gap Ready)' : '100% AIR-GAPPED OFFLINE'}
                  </span>
                </div>

                <div className="p-3 rounded bg-[#121212] border border-[#1e1e1e]">
                  <span className="text-[#666666] block mb-1">LOCAL TELEMETRY LOGS:</span>
                  <span className="text-emerald-400 font-semibold text-sm">0 BEACONS (DISABLED)</span>
                </div>

                <div className="p-3 rounded bg-[#121212] border border-[#1e1e1e]">
                  <span className="text-[#666666] block mb-1">DATABASE STORAGE ENCRYPTION:</span>
                  <span className="text-emerald-400 font-semibold text-sm">AES-GCM-256 (PBKDF2 250k)</span>
                </div>

                <div className="p-3 rounded bg-[#121212] border border-[#1e1e1e]">
                  <span className="text-[#666666] block mb-1">THIRD-PARTY TRACKERS:</span>
                  <span className="text-emerald-400 font-semibold text-sm">ZERO LOADED</span>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-[#0c0c0c] border border-[#1e1e1e] text-[#888888] leading-relaxed font-sans">
                <strong className="text-[#d4d4d4] block mb-1 font-mono">Paranoid Operational Checklist:</strong>
                <ul className="list-disc pl-4 space-y-1 text-xs">
                  <li>Use a trusted VPN or Tor Browser for maximum layer-3 anonymity.</li>
                  <li>Enable the <strong>Panic Cloak (Alt+P)</strong> whenever in public environments.</li>
                  <li>Regularly utilize the <strong>Telegram Exfiltration & Scrub</strong> feature to leave zero local footprints on your hardware.</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
