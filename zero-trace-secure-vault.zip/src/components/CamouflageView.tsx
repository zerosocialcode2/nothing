import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, Terminal, Calculator, AlertCircle, RefreshCw } from 'lucide-react';
import { CamouflageMode } from '../types';

interface CamouflageViewProps {
  onExitDecoy: () => void;
}

export const CamouflageView: React.FC<CamouflageViewProps> = ({ onExitDecoy }) => {
  const [mode, setMode] = useState<'calculator' | 'terminal' | 'error404'>('calculator');

  // Calculator State
  const [calcDisplay, setCalcDisplay] = useState('0');
  const [calcMemory, setCalcMemory] = useState<number | null>(null);
  const [calcOp, setCalcOp] = useState<string | null>(null);
  const [newNumber, setNewNumber] = useState(true);

  // Terminal State
  const [termHistory, setTermHistory] = useState<string[]>([
    'Linux kernel 6.5.0-generic x86_64',
    'System operational. Diagnostic monitors nominal.',
    'Type "help" for available diagnostic utilities.',
  ]);
  const [termInput, setTermInput] = useState('');

  // Keyboard shortcut to exit camouflage
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Escape or Alt+P exits decoy mode
      if (e.key === 'Escape' || (e.altKey && (e.key === 'p' || e.key === 'P'))) {
        onExitDecoy();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onExitDecoy]);

  // Calculator Logic
  const handleCalcNumber = (num: string) => {
    if (newNumber) {
      setCalcDisplay(num);
      setNewNumber(false);
    } else {
      setCalcDisplay(calcDisplay === '0' ? num : calcDisplay + num);
    }
  };

  const handleCalcOp = (op: string) => {
    const current = parseFloat(calcDisplay);
    if (calcMemory === null) {
      setCalcMemory(current);
    } else if (calcOp) {
      const result = executeCalc(calcMemory, current, calcOp);
      setCalcMemory(result);
      setCalcDisplay(String(result));
    }
    setCalcOp(op);
    setNewNumber(true);
  };

  const handleCalcEquals = () => {
    if (calcMemory !== null && calcOp) {
      const current = parseFloat(calcDisplay);
      const result = executeCalc(calcMemory, current, calcOp);
      setCalcDisplay(String(result));
      setCalcMemory(null);
      setCalcOp(null);
      setNewNumber(true);
    }
  };

  const executeCalc = (a: number, b: number, op: string): number => {
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return b !== 0 ? a / b : 0;
      default: return b;
    }
  };

  const handleCalcClear = () => {
    setCalcDisplay('0');
    setCalcMemory(null);
    setCalcOp(null);
    setNewNumber(true);
  };

  // Terminal command handler
  const handleTermCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = termInput.trim();
    if (!cmd) return;

    const newHist = [...termHistory, `user@daemon:~$ ${cmd}`];

    if (cmd === 'help') {
      newHist.push('Available commands: status, top, df, whoami, uname, clear, exit');
    } else if (cmd === 'status') {
      newHist.push('CPU: 1.2% | Memory: 14.8GB / 32GB | Swap: 0% | Uptime: 42d 18h');
    } else if (cmd === 'top') {
      newHist.push('PID USER   %CPU %MEM   TIME+ COMMAND');
      newHist.push('  1 root    0.0  0.1  0:04.1 systemd');
      newHist.push('482 daemon  0.2  0.4  1:12.3 nginx');
      newHist.push('981 user    0.0  0.8  0:22.0 bash');
    } else if (cmd === 'df' || cmd === 'df -h') {
      newHist.push('Filesystem      Size  Used Avail Use% Mounted on');
      newHist.push('/dev/nvme0n1p2  468G  142G  303G  32% /');
    } else if (cmd === 'whoami') {
      newHist.push('daemon-operator');
    } else if (cmd === 'uname -a' || cmd === 'uname') {
      newHist.push('Linux node-01 6.5.0-28-generic #29-Ubuntu SMP PREEMPT_DYNAMIC x86_64 GNU/Linux');
    } else if (cmd === 'clear') {
      setTermHistory([]);
      setTermInput('');
      return;
    } else if (cmd === 'exit' || cmd === 'unlock' || cmd === 'vault') {
      onExitDecoy();
      return;
    } else {
      newHist.push(`bash: ${cmd}: command not found`);
    }

    setTermHistory(newHist);
    setTermInput('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#050505] text-[#d4d4d4] flex flex-col font-sans select-none">
      {/* Decoy Mode Selector Top Micro Bar */}
      <div className="px-4 py-2 bg-[#0a0a0a] border-b border-[#1e1e1e] flex items-center justify-between text-xs text-[#888888] font-mono">
        <div className="flex items-center space-x-2">
          <span>Camouflage Cloak Active</span>
          <span className="text-[#333333]">|</span>
          <span className="text-[10px] text-[#666666]">Press Esc or Alt+P to return</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setMode('calculator')}
            className={`px-2 py-0.5 rounded text-[11px] transition-colors ${mode === 'calculator' ? 'bg-[#1e1e1e] text-white' : 'hover:text-[#d4d4d4]'}`}
          >
            Calculator
          </button>
          <button
            onClick={() => setMode('terminal')}
            className={`px-2 py-0.5 rounded text-[11px] transition-colors ${mode === 'terminal' ? 'bg-[#1e1e1e] text-white' : 'hover:text-[#d4d4d4]'}`}
          >
            Terminal
          </button>
          <button
            onClick={() => setMode('error404')}
            className={`px-2 py-0.5 rounded text-[11px] transition-colors ${mode === 'error404' ? 'bg-[#1e1e1e] text-white' : 'hover:text-[#d4d4d4]'}`}
          >
            404 Screen
          </button>

          <button
            onClick={onExitDecoy}
            className="ml-2 px-2 py-0.5 bg-[#141414] border border-blue-800/50 text-blue-400 rounded text-[11px] hover:bg-[#1e1e1e] transition-colors"
          >
            Exit Decoy
          </button>
        </div>
      </div>

      {/* 1. CALCULATOR MODE */}
      {mode === 'calculator' && (
        <div className="flex-1 flex items-center justify-center p-4 bg-[#050505]">
          <div className="w-80 bg-[#0a0a0a] border border-[#1e1e1e] rounded-2xl p-5 shadow-2xl font-mono">
            <div className="bg-[#121212] border border-[#222222] rounded-xl p-4 mb-4 text-right">
              <span className="text-2xl font-mono text-[#f0f0f0] font-semibold tracking-wider block truncate">
                {calcDisplay}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-sm font-semibold">
              <button onClick={handleCalcClear} className="p-3 bg-red-950/40 text-red-300 border border-red-900/40 rounded-lg hover:bg-red-900/50 transition-colors">C</button>
              <button onClick={() => setCalcDisplay(String(-parseFloat(calcDisplay)))} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">±</button>
              <button onClick={() => setCalcDisplay(String(parseFloat(calcDisplay) / 100))} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">%</button>
              <button onClick={() => handleCalcOp('÷')} className="p-3 bg-[#181818] text-blue-400 border border-[#262626] rounded-lg hover:bg-[#222222] transition-colors">÷</button>

              <button onClick={() => handleCalcNumber('7')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">7</button>
              <button onClick={() => handleCalcNumber('8')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">8</button>
              <button onClick={() => handleCalcNumber('9')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">9</button>
              <button onClick={() => handleCalcOp('×')} className="p-3 bg-[#181818] text-blue-400 border border-[#262626] rounded-lg hover:bg-[#222222] transition-colors">×</button>

              <button onClick={() => handleCalcNumber('4')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">4</button>
              <button onClick={() => handleCalcNumber('5')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">5</button>
              <button onClick={() => handleCalcNumber('6')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">6</button>
              <button onClick={() => handleCalcOp('-')} className="p-3 bg-[#181818] text-blue-400 border border-[#262626] rounded-lg hover:bg-[#222222] transition-colors">-</button>

              <button onClick={() => handleCalcNumber('1')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">1</button>
              <button onClick={() => handleCalcNumber('2')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">2</button>
              <button onClick={() => handleCalcNumber('3')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">3</button>
              <button onClick={() => handleCalcOp('+')} className="p-3 bg-[#181818] text-blue-400 border border-[#262626] rounded-lg hover:bg-[#222222] transition-colors">+</button>

              <button onClick={() => handleCalcNumber('0')} className="p-3 col-span-2 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">0</button>
              <button onClick={() => !calcDisplay.includes('.') && setCalcDisplay(calcDisplay + '.')} className="p-3 bg-[#141414] text-[#d4d4d4] border border-[#222222] rounded-lg hover:bg-[#1e1e1e] transition-colors">.</button>
              <button onClick={handleCalcEquals} className="p-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-500 transition-colors">=</button>
            </div>
          </div>
        </div>
      )}

      {/* 2. TERMINAL MODE */}
      {mode === 'terminal' && (
        <div className="flex-1 p-4 bg-[#050505] text-[#d4d4d4] font-mono text-xs overflow-y-auto flex flex-col justify-between">
          <div className="space-y-1">
            {termHistory.map((line, i) => (
              <div key={i} className="leading-relaxed text-[#a0a0a0]">{line}</div>
            ))}
          </div>

          <form onSubmit={handleTermCommand} className="flex items-center space-x-2 pt-2 border-t border-[#1e1e1e] mt-4">
            <span className="text-blue-400">user@daemon:~$</span>
            <input
              type="text"
              value={termInput}
              onChange={e => setTermInput(e.target.value)}
              className="flex-1 bg-transparent text-[#f0f0f0] focus:outline-none font-mono"
              autoFocus
            />
          </form>
        </div>
      )}

      {/* 3. 404 SCREEN MODE */}
      {mode === 'error404' && (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-[#050505]">
          <h1 className="text-6xl font-bold text-[#2a2a2a] mb-2 font-mono">404</h1>
          <h2 className="text-lg text-[#888888] font-sans mb-1">Page Not Found</h2>
          <p className="text-xs text-[#555555] font-mono max-w-sm">
            The requested resource could not be found on this server. The link you followed may be broken or the page may have been removed.
          </p>
          <div className="mt-6 text-[10px] text-[#444444] font-mono">
            nginx/1.24.0 (Ubuntu)
          </div>
        </div>
      )}
    </div>
  );
};
