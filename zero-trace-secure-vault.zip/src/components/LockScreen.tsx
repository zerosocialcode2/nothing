import React, { useState, useEffect } from 'react';
import { Shield, Fingerprint, Key, AlertTriangle, Eye, EyeOff, Lock, Trash2, Cpu, CheckCircle2, ShieldAlert } from 'lucide-react';
import { checkBiometricSupport, verifyBiometric, registerBiometric } from '../lib/biometrics';
import { purgeAllTraces, hasExistingVault } from '../lib/storage';

interface LockScreenProps {
  onUnlock: (passphrase: string, isDuress: boolean) => Promise<boolean>;
  onTriggerDecoy: () => void;
  duressPin?: string;
  isFirstSetup?: boolean;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  onUnlock,
  onTriggerDecoy,
  duressPin = '9999',
  isFirstSetup = false,
}) => {
  const [passphrase, setPassphrase] = useState('');
  const [confirmPassphrase, setConfirmPassphrase] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [showShredModal, setShowShredModal] = useState(false);
  const [shredConfirmText, setShredConfirmText] = useState('');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    checkBiometricSupport().then(res => {
      setBiometricAvailable(res.isSupported);
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passphrase.trim()) {
      setError('Master Passphrase is required');
      return;
    }

    if (isFirstSetup) {
      if (passphrase.length < 8) {
        setError('Passphrase must be at least 8 characters for cryptographic security.');
        return;
      }
      if (passphrase !== confirmPassphrase) {
        setError('Passphrases do not match.');
        return;
      }
    }

    setLoading(true);
    setError(null);

    // Check if Duress PIN was entered
    if (duressPin && passphrase.trim() === duressPin.trim()) {
      setTimeout(async () => {
        setLoading(false);
        await onUnlock(passphrase, true); // Duress Mode
      }, 400);
      return;
    }

    try {
      const success = await onUnlock(passphrase, false);
      if (!success) {
        setError('Invalid passphrase or decryption failed. Zero-knowledge hash mismatch.');
      }
    } catch (err: any) {
      setError(err.message || 'Decryption failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleBiometricAuth = async () => {
    setError(null);
    setLoading(true);
    try {
      if (isFirstSetup) {
        // Register biometric
        const credId = await registerBiometric();
        if (credId && passphrase) {
          await onUnlock(passphrase, false);
        } else {
          setError('Please provide a master passphrase to pair with biometrics.');
        }
      } else {
        const verified = await verifyBiometric();
        if (verified) {
          // If biometric succeeds, we prompt for stored key or derive
          // In zero-knowledge architecture, master passphrase is required for WebCrypto key derivation
          // Biometrics verify physical presence
          if (!passphrase) {
            setError('Biometric verified. Please enter your passphrase to derive the AES-256 decryption key.');
          } else {
            await onUnlock(passphrase, false);
          }
        }
      }
    } catch (err: any) {
      setError(err.message || 'Biometric authentication was cancelled.');
    } finally {
      setLoading(false);
    }
  };

  const handleEmergencyShred = () => {
    if (shredConfirmText.trim().toUpperCase() === 'SHRED') {
      purgeAllTraces();
      window.location.reload();
    } else {
      setError('Type SHRED to confirm total zero-trace destruction.');
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center p-4 selection:bg-blue-600/30 selection:text-white relative overflow-hidden font-sans">
      {/* Subtle background security grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e1e1e_1px,transparent_1px)] [background-size:24px_24px] opacity-30 pointer-events-none" />

      {/* Top Discreet Bar */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs text-[#888888] font-mono">
        <div className="flex items-center space-x-2">
          <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-amber-400' : 'bg-emerald-400'}`} />
          <span>{isOnline ? 'NETWORK: ACTIVE' : 'AIR-GAPPED / OFFLINE'}</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={onTriggerDecoy}
            className="hover:text-white text-[#aaaaaa] transition-colors flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#111111] border border-[#222222] text-[11px]"
            title="Instant Camouflage"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Decoy Cloak</span>
          </button>
          <button
            onClick={() => setShowShredModal(true)}
            className="hover:text-red-400 text-[#888888] transition-colors flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#161111] border border-red-900/40 text-[11px]"
            title="Emergency Zero-Trace Wipe"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Shred</span>
          </button>
        </div>
      </div>

      {/* Main Lock Card */}
      <div className="w-full max-w-md bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl p-8 shadow-2xl relative z-10">
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-[#141414] border border-[#2a2a2a] flex items-center justify-center text-blue-400 mb-4 shadow-sm">
            <Shield className="w-6 h-6" />
          </div>
          <h1 className="text-lg font-semibold tracking-wide text-[#f0f0f0] font-sans">
            {isFirstSetup ? 'Initialize Zero-Trace Vault' : 'Zero-Knowledge Security Vault'}
          </h1>
          <p className="text-xs text-[#888888] mt-1 font-mono">
            {isFirstSetup
              ? 'Establish master passphrase for AES-GCM 256 encryption'
              : 'End-to-End Encrypted Client Sandbox • Zero Server Logs'}
          </p>
        </div>

        {error && (
          <div className="mb-5 p-3 rounded-lg bg-red-950/40 border border-red-800/60 text-red-300 text-xs flex items-start space-x-2 font-mono">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handlePasswordSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-mono text-[#888888] mb-1.5 uppercase tracking-wider">
              {isFirstSetup ? 'Master Passphrase' : 'Vault Master Key / PIN'}
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={passphrase}
                onChange={e => setPassphrase(e.target.value)}
                placeholder={isFirstSetup ? 'Create strong passphrase...' : 'Enter master passphrase or PIN...'}
                className="w-full bg-[#121212] border border-[#222222] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-blue-500 font-mono transition-all pr-10"
                autoFocus
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#666666] hover:text-[#aaaaaa] transition-colors"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {isFirstSetup && (
            <div>
              <label className="block text-[11px] font-mono text-[#888888] mb-1.5 uppercase tracking-wider">
                Confirm Master Passphrase
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassphrase}
                onChange={e => setConfirmPassphrase(e.target.value)}
                placeholder="Repeat passphrase exactly..."
                className="w-full bg-[#121212] border border-[#222222] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-[#555555] focus:outline-none focus:border-blue-500 font-mono transition-all"
                required
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-sm transition-all duration-150 flex items-center justify-center space-x-2 font-mono shadow-md disabled:opacity-50"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>{isFirstSetup ? 'Encrypt & Initialize Vault' : 'Decrypt & Access Vault'}</span>
              </>
            )}
          </button>
        </form>

        {/* Biometrics Trigger */}
        {biometricAvailable && (
          <div className="mt-5 pt-5 border-t border-[#1e1e1e]">
            <button
              type="button"
              onClick={handleBiometricAuth}
              disabled={loading}
              className="w-full py-2.5 px-4 bg-[#141414] hover:bg-[#1c1c1c] border border-[#262626] text-[#d4d4d4] rounded-lg text-xs font-mono transition-all flex items-center justify-center space-x-2 group"
            >
              <Fingerprint className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span>{isFirstSetup ? 'Enroll Hardware Biometric Key' : 'Authenticate via Hardware Biometrics'}</span>
            </button>
          </div>
        )}

        {/* Security Specs Footer */}
        <div className="mt-6 pt-4 border-t border-[#1a1a1a] flex items-center justify-between text-[10px] font-mono text-[#777777]">
          <span className="flex items-center space-x-1">
            <Cpu className="w-3 h-3 text-[#888888]" />
            <span>PBKDF2 250k • AES-256</span>
          </span>
          <span>Zero Server Logs</span>
        </div>
      </div>

      {/* Emergency Shred Modal */}
      {showShredModal && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-[#130d10] border border-red-800/80 rounded-xl p-6 shadow-2xl text-left">
            <div className="w-12 h-12 rounded-full bg-red-950/60 border border-red-700/60 flex items-center justify-center text-red-400 mb-3">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-base font-semibold text-red-200">Zero-Trace Total Destruction</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed font-mono">
              This will immediately overwrite all encrypted keys, notes, files, and traces in local storage with cryptographic random bytes, then purge all memory. Data cannot be recovered.
            </p>
            <div className="mt-4">
              <label className="block text-[11px] font-mono text-red-400 mb-1">
                Type <strong className="text-white font-bold">SHRED</strong> to confirm:
              </label>
              <input
                type="text"
                value={shredConfirmText}
                onChange={e => setShredConfirmText(e.target.value)}
                placeholder="SHRED"
                className="w-full bg-[#0a0608] border border-red-900 rounded px-3 py-2 text-xs text-red-200 font-mono focus:outline-none focus:border-red-500 uppercase"
              />
            </div>
            <div className="mt-5 flex space-x-2">
              <button
                type="button"
                onClick={() => setShowShredModal(false)}
                className="flex-1 py-2 px-3 bg-[#1e1b24] hover:bg-[#2a2632] text-slate-300 rounded text-xs font-mono"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleEmergencyShred}
                className="flex-1 py-2 px-3 bg-red-600 hover:bg-red-500 text-white rounded text-xs font-mono font-semibold"
              >
                Execute Shred
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
