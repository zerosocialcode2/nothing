import React from 'react';
import {
  Shield,
  Lock,
  Eye,
  Search,
  Send,
  Sliders,
  FileText,
  BookOpen,
  Code2,
  Bookmark,
  FolderLock,
  Wrench,
  Wifi,
  WifiOff,
  Radio,
  HardDrive
} from 'lucide-react';
import { ViewMode } from '../types';

interface StealthHeaderProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  onLock: () => void;
  onTriggerDecoy: () => void;
  onOpenSearch: () => void;
  onOpenTelegram: () => void;
  onOpenSettings: () => void;
  isOnline: boolean;
  telegramConnected: boolean;
  itemCount: number;
}

export const StealthHeader: React.FC<StealthHeaderProps> = ({
  currentView,
  onSelectView,
  onLock,
  onTriggerDecoy,
  onOpenSearch,
  onOpenTelegram,
  onOpenSettings,
  isOnline,
  telegramConnected,
  itemCount,
}) => {
  const navItems: { id: ViewMode; label: string; icon: React.ReactNode }[] = [
    { id: 'vault', label: 'Vault', icon: <FolderLock className="w-3.5 h-3.5" /> },
    { id: 'notes', label: 'Notepad', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'journal', label: 'Journal', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'code', label: 'Code Dev', icon: <Code2 className="w-3.5 h-3.5" /> },
    { id: 'links', label: 'Links', icon: <Bookmark className="w-3.5 h-3.5" /> },
    { id: 'media', label: 'Media Lab', icon: <HardDrive className="w-3.5 h-3.5" /> },
    { id: 'tools', label: 'OpSec Tools', icon: <Wrench className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="bg-[#0a0a0a] border-b border-[#1e1e1e] sticky top-0 z-40 select-none">
      {/* Upper Micro Status Bar */}
      <div className="px-4 py-1.5 bg-[#050505] border-b border-[#1e1e1e] flex items-center justify-between text-[11px] font-mono text-[#888888]">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1.5 text-blue-400">
            <Shield className="w-3.5 h-3.5" />
            <span className="font-semibold text-[#f0f0f0] tracking-wide">ZERO-TRACE VAULT</span>
          </span>
          <span className="text-[#262626]">|</span>
          <span className="text-[#a0a0a0]">CIPHER: AES-GCM-256</span>
          <span className="text-[#262626]">|</span>
          <span className="hidden sm:inline text-[#777777]">RAM: VOLATILE-ONLY</span>
        </div>

        <div className="flex items-center space-x-2.5">
          {/* Network State */}
          <div className="flex items-center space-x-1">
            {isOnline ? (
              <span className="flex items-center space-x-1 text-amber-400/90 text-[10px]" title="Connected to network. Offline mode available.">
                <Wifi className="w-3 h-3" />
                <span className="hidden md:inline">NET ACTIVE</span>
              </span>
            ) : (
              <span className="flex items-center space-x-1 text-emerald-400 text-[10px]" title="Air-gapped / Completely offline. Zero packet risk.">
                <WifiOff className="w-3 h-3" />
                <span className="hidden md:inline">AIR-GAPPED</span>
              </span>
            )}
          </div>

          {/* Telegram Sync Indicator */}
          <button
            onClick={onOpenTelegram}
            className={`flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] transition-colors border ${
              telegramConnected
                ? 'text-sky-400 bg-sky-950/40 border-sky-800/60 hover:bg-sky-900/50'
                : 'text-[#777777] bg-[#111111] border-[#222222] hover:text-[#d4d4d4]'
            }`}
            title="Telegram Bridge Settings"
          >
            <Send className="w-2.5 h-2.5" />
            <span className="hidden md:inline">{telegramConnected ? 'TELEGRAM SYNC' : 'TG BOT'}</span>
          </button>

          <span className="text-[#262626]">|</span>

          {/* Quick Search Shortcut */}
          <button
            onClick={onOpenSearch}
            className="flex items-center space-x-1.5 text-[#aaaaaa] hover:text-white bg-[#111111] hover:bg-[#161616] px-2 py-0.5 rounded border border-[#222222] transition-colors text-[10px]"
            title="Global Search across encrypted database (Ctrl+K)"
          >
            <Search className="w-3 h-3" />
            <span className="hidden sm:inline">Search</span>
            <kbd className="text-[9px] bg-[#1c1c1c] border border-[#2a2a2a] px-1 rounded text-[#888888]">⌘K</kbd>
          </button>

          {/* Panic Decoy Button */}
          <button
            onClick={onTriggerDecoy}
            className="flex items-center space-x-1 text-amber-300 hover:text-amber-200 bg-amber-950/40 hover:bg-amber-900/50 px-2 py-0.5 rounded border border-amber-800/60 transition-colors text-[10px]"
            title="Panic Stealth Cloak (Alt+P)"
          >
            <Eye className="w-3 h-3" />
            <span className="hidden sm:inline">Cloak</span>
          </button>

          {/* Lock Button */}
          <button
            onClick={onLock}
            className="flex items-center space-x-1 text-red-400 hover:text-red-300 bg-red-950/40 hover:bg-red-900/50 px-2 py-0.5 rounded border border-red-800/60 transition-colors text-[10px]"
            title="Lock Vault Immediately (Ctrl+L)"
          >
            <Lock className="w-3 h-3" />
            <span>Lock</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Toolbar */}
      <div className="px-4 py-1.5 flex items-center justify-between overflow-x-auto bg-[#0a0a0a]">
        <nav className="flex items-center space-x-1 min-w-max">
          {navItems.map(item => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-md text-xs font-mono transition-all ${
                  isActive
                    ? 'bg-[#141414] text-white border border-[#2a2a2a] shadow-sm font-semibold'
                    : 'text-[#888888] hover:text-[#e0e0e0] hover:bg-[#111111]'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="flex items-center space-x-2 pl-4">
          <button
            onClick={onOpenSettings}
            className="p-1.5 text-[#888888] hover:text-[#f0f0f0] hover:bg-[#141414] rounded-md transition-colors border border-transparent hover:border-[#222222]"
            title="Security Settings & Cryptographic Key Management"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
