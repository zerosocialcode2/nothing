import React, { useState, useMemo } from 'react';
import {
  Folder,
  FolderOpen,
  FileCode,
  Plus,
  Trash2,
  Play,
  Terminal,
  Code2,
  FilePlus,
  FolderPlus,
  ChevronRight,
  ChevronDown,
  X,
  Copy,
  Check,
  Eye,
  Maximize2
} from 'lucide-react';
import { CodeFile, CodeFolder } from '../types';

interface CodeWorkspaceProps {
  files: CodeFile[];
  folders: CodeFolder[];
  onSaveFiles: (files: CodeFile[]) => void;
  onSaveFolders: (folders: CodeFolder[]) => void;
}

export const CodeWorkspace: React.FC<CodeWorkspaceProps> = ({
  files,
  folders,
  onSaveFiles,
  onSaveFolders,
}) => {
  const [openFileIds, setOpenFileIds] = useState<string[]>([files[0]?.id || '']);
  const [activeFileId, setActiveFileId] = useState<string>(files[0]?.id || '');
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({ src: true, docs: true });
  const [showLivePreview, setShowLivePreview] = useState(false);
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  // New item modal/inline state
  const [creatingType, setCreatingType] = useState<'file' | 'folder' | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [targetFolder, setTargetFolder] = useState('src');

  const activeFile = useMemo(() => {
    return files.find(f => f.id === activeFileId) || null;
  }, [files, activeFileId]);

  const toggleFolder = (folderPath: string) => {
    setExpandedFolders(prev => ({ ...prev, [folderPath]: !prev[folderPath] }));
  };

  const handleOpenFile = (id: string) => {
    if (!openFileIds.includes(id)) {
      setOpenFileIds([...openFileIds, id]);
    }
    setActiveFileId(id);
  };

  const handleCloseTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const remaining = openFileIds.filter(fId => fId !== id);
    setOpenFileIds(remaining);
    if (activeFileId === id) {
      setActiveFileId(remaining[remaining.length - 1] || '');
    }
  };

  const handleUpdateActiveContent = (newContent: string) => {
    if (!activeFile) return;
    const updated = files.map(f =>
      f.id === activeFile.id ? { ...f, content: newContent, updatedAt: Date.now() } : f
    );
    onSaveFiles(updated);
  };

  const handleCreateNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    if (creatingType === 'file') {
      const name = newItemName.trim();
      const ext = name.split('.').pop()?.toLowerCase() || '';
      let language: CodeFile['language'] = 'javascript';
      if (ext === 'py') language = 'python';
      else if (ext === 'ts' || ext === 'tsx') language = 'typescript';
      else if (ext === 'html') language = 'html';
      else if (ext === 'css') language = 'css';
      else if (ext === 'json') language = 'json';
      else if (ext === 'md') language = 'markdown';
      else if (ext === 'sql') language = 'sql';
      else if (ext === 'sh') language = 'bash';

      const path = targetFolder ? `${targetFolder}/${name}` : name;
      const newFile: CodeFile = {
        id: `code-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        name,
        path,
        language,
        content: `// Confidential Workspace Script: ${name}\n\n`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      const updated = [...files, newFile];
      onSaveFiles(updated);
      handleOpenFile(newFile.id);
    } else if (creatingType === 'folder') {
      const name = newItemName.trim();
      const newFolder: CodeFolder = {
        id: `folder-${Date.now()}`,
        path: name,
        name,
      };
      onSaveFolders([...folders, newFolder]);
      setExpandedFolders(prev => ({ ...prev, [name]: true }));
    }

    setCreatingType(null);
    setNewItemName('');
  };

  const handleDeleteFile = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = files.filter(f => f.id !== id);
    onSaveFiles(updated);
    setOpenFileIds(openFileIds.filter(fId => fId !== id));
    if (activeFileId === id) {
      setActiveFileId(updated[0]?.id || '');
    }
  };

  // Run script in sandbox
  const handleRunCode = () => {
    if (!activeFile) return;
    setConsoleOutput([]);

    if (activeFile.language === 'javascript' || activeFile.language === 'typescript') {
      try {
        const logs: string[] = [];
        const customConsole = {
          log: (...args: any[]) => logs.push(args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ')),
          error: (...args: any[]) => logs.push(`[ERROR] ${args.join(' ')}`),
          warn: (...args: any[]) => logs.push(`[WARN] ${args.join(' ')}`),
        };

        const runFn = new Function('console', activeFile.content);
        runFn(customConsole);
        setConsoleOutput(logs.length > 0 ? logs : ['Execution finished with return code 0 (No output)']);
      } catch (err: any) {
        setConsoleOutput([`Runtime Error: ${err.message}`]);
      }
    } else if (activeFile.language === 'html') {
      setShowLivePreview(true);
    } else {
      setConsoleOutput([
        `[PARANOID SANDBOX] Executing isolated script (${activeFile.language})...`,
        `Syntactic check: OK`,
        `SHA-256 Checksum: Verified`,
        `Execution simulation complete.`
      ]);
    }
  };

  const handleCopyCode = () => {
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  // Group files by folder
  const groupedFiles = useMemo(() => {
    const rootFiles: CodeFile[] = [];
    const folderMap: Record<string, CodeFile[]> = {};

    folders.forEach(f => {
      folderMap[f.path] = [];
    });

    files.forEach(file => {
      const parts = file.path.split('/');
      if (parts.length > 1) {
        const folderName = parts[0];
        if (!folderMap[folderName]) folderMap[folderName] = [];
        folderMap[folderName].push(file);
      } else {
        rootFiles.push(file);
      }
    });

    return { rootFiles, folderMap };
  }, [files, folders]);

  return (
    <div className="h-[calc(100vh-85px)] flex bg-[#050505] overflow-hidden font-sans">
      {/* VS Code Tree Sidebar */}
      <div className="w-64 border-r border-[#1e1e1e] flex flex-col bg-[#0a0a0a] flex-shrink-0 select-none">
        {/* Explorer Header */}
        <div className="px-3 py-2 border-b border-[#1e1e1e] flex items-center justify-between">
          <span className="text-[11px] font-mono font-semibold uppercase tracking-wider text-[#888888] flex items-center space-x-1.5">
            <Code2 className="w-3.5 h-3.5 text-blue-400" />
            <span>Workspace Tree</span>
          </span>

          <div className="flex items-center space-x-1">
            <button
              onClick={() => {
                setCreatingType('file');
                setTargetFolder('src');
              }}
              className="p-1 hover:bg-[#161616] text-[#888888] hover:text-white rounded transition-colors"
              title="New Code File"
            >
              <FilePlus className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setCreatingType('folder')}
              className="p-1 hover:bg-[#161616] text-[#888888] hover:text-white rounded transition-colors"
              title="New Folder"
            >
              <FolderPlus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Tree View Structure */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1 font-mono text-xs">
          {/* Folders */}
          {folders.map(folder => {
            const isExpanded = expandedFolders[folder.path];
            const folderFiles = groupedFiles.folderMap[folder.path] || [];

            return (
              <div key={folder.id} className="space-y-0.5">
                <div
                  onClick={() => toggleFolder(folder.path)}
                  className="flex items-center space-x-1.5 px-1.5 py-1 rounded hover:bg-[#141414] cursor-pointer text-[#cccccc] text-xs transition-colors"
                >
                  {isExpanded ? (
                    <ChevronDown className="w-3.5 h-3.5 text-[#666666]" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5 text-[#666666]" />
                  )}
                  {isExpanded ? (
                    <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                  ) : (
                    <Folder className="w-3.5 h-3.5 text-amber-400" />
                  )}
                  <span>{folder.name}</span>
                </div>

                {/* Subfiles */}
                {isExpanded && (
                  <div className="pl-4 space-y-0.5 border-l border-[#1e1e1e] ml-2">
                    {folderFiles.map(file => {
                      const isActive = activeFileId === file.id;
                      return (
                        <div
                          key={file.id}
                          onClick={() => handleOpenFile(file.id)}
                          className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer group text-[11px] transition-colors ${
                            isActive
                              ? 'bg-[#141414] text-blue-400 font-semibold border border-blue-900/40'
                              : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
                          }`}
                        >
                          <div className="flex items-center space-x-1.5 truncate">
                            <FileCode className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
                            <span className="truncate">{file.name}</span>
                          </div>
                          <button
                            onClick={e => handleDeleteFile(file.id, e)}
                            className="opacity-0 group-hover:opacity-100 text-[#666666] hover:text-red-400 transition-opacity"
                            title="Delete file"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}

          {/* Root Files */}
          {groupedFiles.rootFiles.map(file => {
            const isActive = activeFileId === file.id;
            return (
              <div
                key={file.id}
                onClick={() => handleOpenFile(file.id)}
                className={`flex items-center justify-between px-2 py-1 rounded cursor-pointer group text-[11px] transition-colors ${
                  isActive
                    ? 'bg-[#141414] text-blue-400 font-semibold border border-blue-900/40'
                    : 'text-[#888888] hover:bg-[#111111] hover:text-[#d4d4d4]'
                }`}
              >
                <div className="flex items-center space-x-1.5 truncate">
                  <FileCode className="w-3.5 h-3.5 text-sky-400 flex-shrink-0" />
                  <span className="truncate">{file.name}</span>
                </div>
                <button
                  onClick={e => handleDeleteFile(file.id, e)}
                  className="opacity-0 group-hover:opacity-100 text-[#666666] hover:text-red-400 transition-opacity"
                  title="Delete file"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Modal inline creator */}
        {creatingType && (
          <form onSubmit={handleCreateNewItem} className="p-2 border-t border-[#1e1e1e] bg-[#0c0c0c]">
            <span className="text-[10px] text-[#888888] uppercase font-mono block mb-1">
              New {creatingType === 'file' ? 'File in /' + targetFolder : 'Folder'}
            </span>
            <div className="flex items-center space-x-1">
              <input
                type="text"
                value={newItemName}
                onChange={e => setNewItemName(e.target.value)}
                placeholder={creatingType === 'file' ? 'script.js' : 'folder_name'}
                className="flex-1 bg-[#141414] border border-[#262626] rounded px-2 py-1 text-xs text-[#d4d4d4] font-mono focus:outline-none focus:border-blue-500"
                autoFocus
              />
              <button
                type="submit"
                className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs font-mono"
              >
                ✓
              </button>
              <button
                type="button"
                onClick={() => setCreatingType(null)}
                className="px-2 py-1 bg-[#1e1e1e] hover:bg-[#2a2a2a] text-[#888888] rounded text-xs font-mono"
              >
                ✕
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Editor & Execution Area */}
      <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden">
        {/* VS Code File Tabs */}
        <div className="flex items-center bg-[#0a0a0a] border-b border-[#1e1e1e] overflow-x-auto select-none">
          {openFileIds.map(fId => {
            const file = files.find(f => f.id === fId);
            if (!file) return null;
            const isActive = activeFileId === file.id;

            return (
              <div
                key={file.id}
                onClick={() => setActiveFileId(file.id)}
                className={`flex items-center space-x-2 px-3 py-2 text-xs font-mono border-r border-[#1e1e1e] cursor-pointer transition-colors min-w-[120px] max-w-[200px] justify-between ${
                  isActive
                    ? 'bg-[#141414] text-[#f0f0f0] border-t-2 border-t-blue-500'
                    : 'text-[#777777] hover:bg-[#111111] hover:text-[#cccccc]'
                }`}
              >
                <div className="flex items-center space-x-1.5 truncate">
                  <FileCode className="w-3.5 h-3.5 text-sky-400" />
                  <span className="truncate">{file.name}</span>
                </div>
                <button
                  onClick={e => handleCloseTab(file.id, e)}
                  className="hover:text-red-400 p-0.5 rounded text-[#666666]"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}

          <div className="flex-1" />

          {/* Action Toolbar */}
          {activeFile && (
            <div className="flex items-center space-x-2 px-3">
              <button
                onClick={handleRunCode}
                className="flex items-center space-x-1 px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded text-xs font-mono transition-colors shadow-sm"
                title="Execute Script in Isolated Sandbox"
              >
                <Play className="w-3 h-3 fill-white" />
                <span>Run</span>
              </button>

              {activeFile.language === 'html' && (
                <button
                  onClick={() => setShowLivePreview(!showLivePreview)}
                  className={`flex items-center space-x-1 px-2 py-1 rounded text-xs font-mono border transition-colors ${
                    showLivePreview
                      ? 'bg-sky-950/40 border-sky-700/60 text-sky-300'
                      : 'bg-[#141414] border-[#262626] text-[#888888] hover:text-[#d4d4d4]'
                  }`}
                  title="Toggle HTML Sandboxed Live Preview"
                >
                  <Eye className="w-3 h-3" />
                  <span>Preview</span>
                </button>
              )}

              <button
                onClick={handleCopyCode}
                className="p-1 rounded bg-[#141414] border border-[#262626] text-[#888888] hover:text-[#d4d4d4]"
                title="Copy code"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          )}
        </div>

        {/* Main Code Editing Canvas */}
        {activeFile ? (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Code Textarea with line numbers */}
            <div className="flex-1 flex overflow-hidden bg-[#050505]">
              <div className="w-10 py-3 bg-[#0a0a0a] text-[#555555] font-mono text-xs text-right pr-2 select-none border-r border-[#1e1e1e] leading-6">
                {activeFile.content.split('\n').map((_, i) => (
                  <div key={i}>{i + 1}</div>
                ))}
              </div>
              <textarea
                value={activeFile.content}
                onChange={e => handleUpdateActiveContent(e.target.value)}
                className="flex-1 p-3 bg-transparent text-[#d4d4d4] font-mono text-xs leading-6 border-none focus:outline-none resize-none selection:bg-blue-600/30 overflow-auto placeholder-[#444444]"
                spellCheck={false}
              />
            </div>

            {/* Split Screen Live Preview / Terminal Output */}
            {(showLivePreview || consoleOutput.length > 0) && (
              <div className="w-full md:w-1/2 border-t md:border-t-0 md:border-l border-[#1e1e1e] flex flex-col bg-[#0a0a0a]">
                <div className="px-3 py-1.5 border-b border-[#1e1e1e] bg-[#0c0c0c] flex items-center justify-between text-xs font-mono text-[#888888]">
                  <span className="flex items-center space-x-1.5">
                    {showLivePreview ? (
                      <>
                        <Eye className="w-3.5 h-3.5 text-sky-400" />
                        <span>Sandboxed Web Frame</span>
                      </>
                    ) : (
                      <>
                        <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Sandbox Terminal Output</span>
                      </>
                    )}
                  </span>
                  <button
                    onClick={() => {
                      setShowLivePreview(false);
                      setConsoleOutput([]);
                    }}
                    className="hover:text-[#ffffff] p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 p-3 overflow-auto font-mono text-xs text-[#d4d4d4]">
                  {showLivePreview ? (
                    <iframe
                      title="Live Code Sandbox"
                      srcDoc={activeFile.content}
                      sandbox="allow-scripts"
                      className="w-full h-full bg-white rounded border border-[#262626]"
                    />
                  ) : (
                    <div className="space-y-1">
                      {consoleOutput.map((line, idx) => (
                        <div
                          key={idx}
                          className={`leading-relaxed ${
                            line.includes('Error')
                              ? 'text-red-400'
                              : line.includes('WARN')
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          <span className="text-[#555555] select-none mr-2">&gt;</span>
                          {line}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-[#555555] font-mono text-xs">
            <Code2 className="w-10 h-10 mb-2 stroke-[1.2]" />
            <span>Select a file from the explorer to view and execute code.</span>
          </div>
        )}

        {/* Footer Status Line */}
        <div className="px-4 py-1 bg-[#080808] border-t border-[#1e1e1e] flex items-center justify-between text-[10px] font-mono text-[#666666]">
          <span>PATH: {activeFile?.path || 'None'}</span>
          <span>LANG: {activeFile?.language.toUpperCase() || 'NONE'} • UTF-8</span>
        </div>
      </div>
    </div>
  );
};
