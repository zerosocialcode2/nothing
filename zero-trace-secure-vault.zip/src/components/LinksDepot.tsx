import React, { useState, useMemo } from 'react';
import {
  Bookmark,
  Plus,
  Trash2,
  ExternalLink,
  Search,
  Shield,
  Tag,
  Globe,
  Lock,
  Copy,
  Check,
  Radio,
  FileText
} from 'lucide-react';
import { LinkItem } from '../types';

interface LinksDepotProps {
  links: LinkItem[];
  onSaveLinks: (updated: LinkItem[]) => void;
}

export const LinksDepot: React.FC<LinksDepotProps> = ({ links, onSaveLinks }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Privacy');
  const [tags, setTags] = useState('OpSec, Research');
  const [safetyScore, setSafetyScore] = useState<LinkItem['safetyScore']>('secure');
  const [notes, setNotes] = useState('');

  const categories = useMemo(() => {
    const set = new Set<string>();
    links.forEach(l => {
      if (l.category) set.add(l.category);
    });
    return Array.from(set);
  }, [links]);

  const filteredLinks = useMemo(() => {
    return links.filter(l => {
      const matchesSearch =
        l.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        l.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.description && l.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
        l.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCat = !selectedCategory || l.category === selectedCategory;
      return matchesSearch && matchesCat;
    });
  }, [links, searchQuery, selectedCategory]);

  const handleAddLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    let cleanUrl = url.trim();
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://') && !cleanUrl.endsWith('.onion')) {
      cleanUrl = 'https://' + cleanUrl;
    }

    const newLink: LinkItem = {
      id: `link-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      title: title.trim() || cleanUrl.replace(/^https?:\/\//, ''),
      url: cleanUrl,
      description: description.trim(),
      category: category.trim() || 'General',
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      safetyScore: cleanUrl.includes('.onion') ? 'onion' : safetyScore,
      createdAt: Date.now(),
      notes: notes.trim(),
    };

    onSaveLinks([newLink, ...links]);
    setShowAddModal(false);
    // Reset Form
    setTitle('');
    setUrl('');
    setDescription('');
    setNotes('');
  };

  const handleDeleteLink = (id: string) => {
    onSaveLinks(links.filter(l => l !== null && l.id !== id));
  };

  const handleCopyUrl = (linkUrl: string, id: string) => {
    navigator.clipboard.writeText(linkUrl);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const getSafetyBadge = (score?: LinkItem['safetyScore']) => {
    switch (score) {
      case 'onion':
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/50 border border-purple-800/60 text-purple-300 flex items-center space-x-1">
            <Radio className="w-2.5 h-2.5 text-purple-400" />
            <span>TOR ONION</span>
          </span>
        );
      case 'secure':
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/50 border border-emerald-800/60 text-emerald-300 flex items-center space-x-1">
            <Shield className="w-2.5 h-2.5 text-emerald-400" />
            <span>VERIFIED SAFE</span>
          </span>
        );
      case 'caution':
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/50 border border-amber-800/60 text-amber-300 flex items-center space-x-1">
            <span>CAUTION</span>
          </span>
        );
      default:
        return (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
            STANDARD
          </span>
        );
    }
  };

  return (
    <div className="h-[calc(100vh-85px)] flex flex-col bg-[#050505] overflow-hidden font-sans">
      {/* Top Header & Search Bar */}
      <div className="p-4 border-b border-[#1e1e1e] bg-[#0a0a0a] flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-[#141414] border border-[#2a2a2a] flex items-center justify-center text-blue-400">
            <Bookmark className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-[#f0f0f0] font-sans">Encrypted Links & URL Depot</h2>
            <p className="text-xs text-[#888888] font-mono">Zero-leak encrypted bookmarks & darkweb resource library</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#666666]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search links, tags, notes..."
              className="bg-[#121212] border border-[#222222] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#d4d4d4] placeholder-[#555555] focus:outline-none focus:border-blue-500 font-mono w-48 md:w-64 transition-colors"
            />
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded-lg text-xs font-mono transition-colors shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Save Link</span>
          </button>
        </div>
      </div>

      {/* Category Pills */}
      <div className="px-4 py-2 border-b border-[#1e1e1e] bg-[#080808] flex items-center space-x-1.5 overflow-x-auto text-xs font-mono">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-2.5 py-1 rounded-md transition-colors border ${
            selectedCategory === null
              ? 'bg-[#1e1e1e] text-white border-[#333333] font-semibold'
              : 'bg-[#101010] text-[#777777] border-[#1e1e1e] hover:text-[#d4d4d4]'
          }`}
        >
          All ({links.length})
        </button>
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat === selectedCategory ? null : cat)}
            className={`px-2.5 py-1 rounded-md transition-colors border ${
              selectedCategory === cat
                ? 'bg-blue-950/60 text-blue-200 border-blue-700/60 font-semibold'
                : 'bg-[#101010] text-[#777777] border-[#1e1e1e] hover:text-[#d4d4d4]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Links Grid */}
      <div className="flex-1 p-4 overflow-y-auto">
        {filteredLinks.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-[#555555] font-mono text-xs">
            <Bookmark className="w-10 h-10 mb-2 stroke-[1.2]" />
            <span>No encrypted links found. Save your first confidential bookmark.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredLinks.map(link => (
              <div
                key={link.id}
                className="bg-[#0b0b0b] border border-[#1e1e1e] hover:border-[#2a2a2a] rounded-xl p-4 flex flex-col justify-between transition-all group shadow-sm"
              >
                <div>
                  <div className="flex items-start justify-between mb-2">
                    {getSafetyBadge(link.safetyScore)}
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => handleCopyUrl(link.url, link.id)}
                        className="p-1 rounded text-[#666666] hover:text-white hover:bg-[#161616] transition-colors"
                        title="Copy Clean URL"
                      >
                        {copiedId === link.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button
                        onClick={() => handleDeleteLink(link.id)}
                        className="p-1 rounded text-[#666666] hover:text-red-400 hover:bg-[#161616] transition-colors"
                        title="Delete Link"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-sm font-semibold text-[#f0f0f0] font-sans group-hover:text-blue-400 transition-colors">
                    {link.title}
                  </h3>

                  <p className="text-xs font-mono text-[#888888] truncate mt-1 bg-[#121212] px-2 py-1 rounded border border-[#1e1e1e]">
                    {link.url}
                  </p>

                  {link.description && (
                    <p className="text-xs text-[#888888] mt-2 font-sans line-clamp-2">
                      {link.description}
                    </p>
                  )}

                  {link.notes && (
                    <div className="mt-2 p-2 rounded bg-[#121212] border border-[#1e1e1e] text-[11px] text-[#888888] font-mono flex items-start space-x-1.5">
                      <FileText className="w-3 h-3 flex-shrink-0 mt-0.5 text-blue-400" />
                      <span>{link.notes}</span>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex items-center justify-between">
                  <div className="flex items-center space-x-1 flex-wrap gap-1">
                    {link.tags.map(t => (
                      <span
                        key={t}
                        className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#141414] border border-[#222222] text-[#888888]"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>

                  <a
                    href={link.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="p-1.5 rounded-lg bg-[#141414] hover:bg-[#1c1c1c] text-[#d4d4d4] hover:text-white border border-[#262626] text-xs font-mono flex items-center space-x-1 transition-colors"
                    title="Launch URL in sandboxed tab (rel=noreferrer)"
                  >
                    <span>Launch</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Link Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#0c0c0c] border border-[#1e1e1e] rounded-xl p-6 shadow-2xl">
            <h3 className="text-sm font-semibold text-[#f0f0f0] mb-4 font-sans flex items-center space-x-2">
              <Bookmark className="w-4 h-4 text-blue-400" />
              <span>Save Encrypted Confidential Link</span>
            </h3>

            <form onSubmit={handleAddLink} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-[#888888] mb-1">Target URL / Onion Address *</label>
                <input
                  type="text"
                  value={url}
                  onChange={e => setUrl(e.target.value)}
                  placeholder="https://example.com or .onion"
                  className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[#888888] mb-1">Link Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Encrypted Mail Portal"
                  className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[#888888] mb-1">Category</label>
                  <input
                    type="text"
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    placeholder="Privacy, Security..."
                    className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[#888888] mb-1">Safety Badge</label>
                  <select
                    value={safetyScore}
                    onChange={e => setSafetyScore(e.target.value as any)}
                    className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500"
                  >
                    <option value="secure">Verified Safe</option>
                    <option value="onion">Tor Onion</option>
                    <option value="neutral">Neutral</option>
                    <option value="caution">Caution</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[#888888] mb-1">Tags (Comma-separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={e => setTags(e.target.value)}
                  placeholder="OpSec, Keys, Essential"
                  className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[#888888] mb-1">Confidential Notes</label>
                <textarea
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Internal notes on login procedures or threat profile..."
                  className="w-full bg-[#141414] border border-[#262626] rounded px-3 py-2 text-[#d4d4d4] focus:outline-none h-16 resize-none focus:border-blue-500"
                />
              </div>

              <div className="pt-3 flex space-x-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 bg-[#1a1a1a] hover:bg-[#262626] text-[#888888] rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded"
                >
                  Encrypt & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
