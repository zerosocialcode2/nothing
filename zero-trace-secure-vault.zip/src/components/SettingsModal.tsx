import React, { useState } from 'react';
import {
  Sliders,
  Shield,
  Key,
  Fingerprint,
  Download,
  Upload,
  Trash2,
  Lock,
  X,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  ShieldAlert
} from 'lucide-react';
import { SecuritySettings, VaultState } from '../types';
import { registerBiometric, checkBiometricSupport } from '../lib/biometrics';
import { getRawEncryptedVault, importRawEncryptedVault, purgeAllTraces } from '../lib/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SecuritySettings;
  onSaveSettings: (settings: SecuritySettings) => void;
  onChangePassphrase: (oldPass: string, newPass: string) => Promise<boolean>;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onChangePassphrase,
}) => {
  const [autoLockMinutes, setAutoLockMinutes] = useState(settings.autoLockMinutes || 5);
  const [duressPin, setDuressPin] = useState(settings.duressPin || '9999');
  const [autoLockOnBlur, setAutoLockOnBlur] = useState(settings.autoLockOnBlur ?? false);
  const [stealthTabTitle, setStealthTabTitle] = useState(settings.stealthTabTitle ?? false);

  // Passphrase Change State
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [passMsg, setPassMsg] = useState<{ success: boolean; text: string } | null>(null);

  // Biometrics
  const [biometricEnrolled, setBiometricEnrolled] = useState(false);

  // Backup Import/Export
  const [importStatus, setImportStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSaveGeneral = () => {
    onSaveSettings({
      ...settings,
      autoLockMinutes,
      duressPin: duressPin.trim(),
      autoLockOnBlur,
      stealthTabTitle,
    });
    if (stealthTabTitle) {
      document.title = 'Disk Management Utility';
    } else {
      document.title = 'Vault — Zero Trace';
    }
  };

  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);

    if (newPass.length < 8) {
      setPassMsg({ success: false, text: 'New passphrase must be at least 8 characters long.' });
      return;
    }
    if (newPass !== confirmNewPass) {
      setPassMsg({ success: false, text: 'New passphrases do not match.' });
      return;
    }

    try {
      const ok = await onChangePassphrase(currentPass, newPass);
      if (ok) {
        setPassMsg({ success: true, text: 'Master cryptographic key successfully updated and re-encrypted.' });
        setCurrentPass('');
        setNewPass('');
        setConfirmNewPass('');
      } else {
        setPassMsg({ success: false, text: 'Current passphrase verification failed.' });
      }
    } catch (err: any) {
      setPassMsg({ success: false, text: err.message || 'Passphrase change failed.' });
    }
  };

  const handleEnrollBiometric = async () => {
    try {
      const credId = await registerBiometric('vault-operator');
      if (credId) {
        onSaveSettings({
          ...settings,
          biometricsEnabled: true,
          biometricCredentialId: credId,
        });
        setBiometricEnrolled(true);
      }
    } catch (err: any) {
      alert('Biometric enrollment note: ' + (err.message || 'Device biometrics rejected or unavailable.'));
    }
  };

  const handleExportEncryptedFile = () => {
    const raw = getRawEncryptedVault();
    if (!raw) {
      alert('No encrypted vault payload found.');
      return;
    }
    const blob = new Blob([raw], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zero-trace-vault-backup-${new Date().toISOString().slice(0, 10)}.ztvault.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportEncryptedFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = reader.result as string;
        // Basic JSON sanity check
        JSON.parse(text);
        importRawEncryptedVault(text);
        setImportStatus('Backup loaded. Please lock and re-authenticate with the backup master key.');
      } catch {
        alert('Invalid encrypted backup file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleTotalPurge = () => {
    if (confirm('CRITICAL WARNING: This will immediately shred all encrypted vault records, keys, and memory traces. This action is irreversible. Continue?')) {
      purgeAllTraces();
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm font-sans">
      <div className="w-full max-w-2xl bg-[#0a0a0a] border border-[#1e1e1e] rounded-xl shadow-2xl overflow-hidden flex flex-col font-mono text-xs max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-[#1e1e1e] bg-[#0d0d0d] flex items-center justify-between">
          <div className="flex items-center space-x-2 text-[#f0f0f0] font-sans font-semibold text-sm">
            <Sliders className="w-4 h-4 text-blue-400" />
            <span>Vault Security & Cryptographic Settings</span>
          </div>
          <button onClick={onClose} className="text-[#888888] hover:text-[#d4d4d4]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* General Security & Lock Timer */}
          <div className="bg-[#121212] border border-[#222222] rounded-lg p-4 space-y-3">
            <h4 className="font-semibold text-[#f0f0f0] font-sans text-xs">Security & Auto-Lock Parameters</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[#888888] mb-1">Inactivity Auto-Lock ({autoLockMinutes} minutes):</label>
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={autoLockMinutes}
                  onChange={e => setAutoLockMinutes(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-[#1e1e1e] rounded appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              <div>
                <label className="block text-[#888888] mb-1">Duress Stealth PIN (Decoy Mode):</label>
                <input
                  type="text"
                  value={duressPin}
                  onChange={e => setDuressPin(e.target.value)}
                  placeholder="e.g. 9999"
                  className="w-full bg-[#181818] border border-[#2a2a2a] rounded px-2.5 py-1.5 text-[#d4d4d4] focus:outline-none focus:border-blue-500 font-mono"
                />
                <p className="text-[10px] text-[#666666] mt-1">
                  Entering this PIN on the lock screen silently opens a harmless decoy vault.
                </p>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-[#1e1e1e]">
              <label className="flex items-center space-x-2 cursor-pointer text-[#d4d4d4]">
                <input
                  type="checkbox"
                  checked={autoLockOnBlur}
                  onChange={e => setAutoLockOnBlur(e.target.checked)}
                  className="rounded bg-[#181818] border-[#2a2a2a] text-blue-500"
                />
                <span>Auto-Lock Vault when browser tab loses focus / minimizes</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer text-[#d4d4d4]">
                <input
                  type="checkbox"
                  checked={stealthTabTitle}
                  onChange={e => setStealthTabTitle(e.target.checked)}
                  className="rounded bg-[#181818] border-[#2a2a2a] text-blue-500"
                />
                <span>Camouflage Tab Title (disguises browser tab as "Disk Management Utility")</span>
              </label>
            </div>

            <button
              type="button"
              onClick={handleSaveGeneral}
              className="py-1.5 px-3 bg-[#1a1a1a] hover:bg-[#262626] text-[#d4d4d4] border border-[#333333] rounded font-semibold transition-colors mt-2"
            >
              Apply General Settings
            </button>
          </div>

          {/* Biometrics Pairing */}
          <div className="bg-[#121212] border border-[#222222] rounded-lg p-4 space-y-3">
            <h4 className="font-semibold text-[#f0f0f0] font-sans text-xs flex items-center space-x-2">
              <Fingerprint className="w-4 h-4 text-blue-400" />
              <span>Hardware Biometrics & Passkeys</span>
            </h4>
            <p className="text-[#888888] font-sans">
              Pair your device's TouchID, FaceID, Windows Hello, or FIDO2 hardware security key for rapid biometric authorization.
            </p>
            <button
              onClick={handleEnrollBiometric}
              className="py-2 px-4 bg-[#141414] hover:bg-[#1e1e1e] border border-blue-800/40 text-blue-400 rounded font-semibold transition-colors flex items-center space-x-2"
            >
              <Fingerprint className="w-4 h-4" />
              <span>Enroll / Re-pair Hardware Biometrics</span>
            </button>
          </div>

          {/* Change Master Passphrase */}
          <form onSubmit={handleChangePasswordSubmit} className="bg-[#121212] border border-[#222222] rounded-lg p-4 space-y-3">
            <h4 className="font-semibold text-[#f0f0f0] font-sans text-xs flex items-center space-x-2">
              <Key className="w-4 h-4 text-amber-400" />
              <span>Change Master Cryptographic Key</span>
            </h4>

            <div>
              <label className="block text-[#888888] mb-1">Current Master Passphrase:</label>
              <input
                type="password"
                value={currentPass}
                onChange={e => setCurrentPass(e.target.value)}
                className="w-full bg-[#181818] border border-[#2a2a2a] rounded px-2.5 py-1.5 text-[#d4d4d4] focus:outline-none focus:border-blue-500 font-mono"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-[#888888] mb-1">New Master Passphrase (8+ chars):</label>
                <input
                  type="password"
                  value={newPass}
                  onChange={e => setNewPass(e.target.value)}
                  className="w-full bg-[#181818] border border-[#2a2a2a] rounded px-2.5 py-1.5 text-[#d4d4d4] focus:outline-none focus:border-blue-500 font-mono"
                  required
                />
              </div>
              <div>
                <label className="block text-[#888888] mb-1">Confirm New Passphrase:</label>
                <input
                  type="password"
                  value={confirmNewPass}
                  onChange={e => setConfirmNewPass(e.target.value)}
                  className="w-full bg-[#181818] border border-[#2a2a2a] rounded px-2.5 py-1.5 text-[#d4d4d4] focus:outline-none focus:border-blue-500 font-mono"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="py-1.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-medium rounded transition-colors"
            >
              Re-Key Vault Database
            </button>

            {passMsg && (
              <div className={`p-2.5 rounded text-xs flex items-center space-x-2 ${passMsg.success ? 'bg-emerald-950/50 text-emerald-300' : 'bg-red-950/50 text-red-300'}`}>
                {passMsg.success ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
                <span>{passMsg.text}</span>
              </div>
            )}
          </form>

          {/* Export & Import Encrypted Cold Backups */}
          <div className="bg-[#121212] border border-[#222222] rounded-lg p-4 space-y-3">
            <h4 className="font-semibold text-[#f0f0f0] font-sans text-xs">Cold Storage Backup & Disaster Recovery</h4>
            <div className="flex items-center space-x-3">
              <button
                onClick={handleExportEncryptedFile}
                className="py-2 px-3 bg-[#1a1a1a] hover:bg-[#262626] text-[#d4d4d4] border border-[#333333] rounded flex items-center space-x-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Encrypted .ztvault File</span>
              </button>

              <label className="py-2 px-3 bg-[#1a1a1a] hover:bg-[#262626] text-[#d4d4d4] border border-[#333333] rounded flex items-center space-x-1.5 transition-colors cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>Import Encrypted Backup</span>
                <input type="file" accept=".json,.ztvault" onChange={handleImportEncryptedFile} className="hidden" />
              </label>
            </div>
            {importStatus && <p className="text-emerald-400 text-xs">{importStatus}</p>}
          </div>

          {/* Emergency Zero-Trace Shredder */}
          <div className="bg-[#14080a] border border-red-900/60 rounded-lg p-4 space-y-2">
            <h4 className="font-semibold text-red-400 font-sans text-xs flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <span>Nuclear Zero-Trace Memory & Storage Shredder</span>
            </h4>
            <p className="text-[#888888] font-sans text-xs">
              Instantly overwrites all storage sectors with cryptographic noise, flushes RAM, wipes service caches, and locks down the device with zero recoverable metadata.
            </p>
            <button
              onClick={handleTotalPurge}
              className="py-2 px-4 bg-red-600 hover:bg-red-500 text-white font-medium rounded transition-colors flex items-center space-x-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Shred All Data Immediately</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
