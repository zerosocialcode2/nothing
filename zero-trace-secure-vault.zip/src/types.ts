export type ViewMode = 
  | 'vault' 
  | 'notes' 
  | 'journal' 
  | 'code' 
  | 'links' 
  | 'media' 
  | 'tools' 
  | 'telegram' 
  | 'settings';

export type CamouflageMode = 'none' | 'calculator' | 'terminal' | 'error404' | 'system_monitor';

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  tags: string[];
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
  expiresAt?: number | null; // Self-destruct timestamp
  burnOnRead?: boolean;
}

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  date: string; // YYYY-MM-DD
  timestamp: number;
  paranoiaLevel: number; // 1 (Relaxed) to 5 (High Threat Alert)
  mood: 'focused' | 'vigilant' | 'secure' | 'concerned' | 'isolated';
  securityAssessment: string;
  hash: string; // Tamper-evident SHA-256 hash chaining
  previousHash: string;
  tags: string[];
}

export interface VaultFile {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  category: 'image' | 'pdf' | 'audio' | 'video' | 'document' | 'other';
  dataUrl: string; // Decrypted base64 / blob URL in RAM
  encryptedBlob?: string; // Stored AES payload
  iv?: string;
  salt?: string;
  tags: string[];
  createdAt: number;
  notes?: string;
  exifStripped?: boolean;
}

export interface CodeFile {
  id: string;
  name: string;
  path: string; // e.g. "src/app.js"
  language: 'javascript' | 'typescript' | 'python' | 'html' | 'css' | 'json' | 'markdown' | 'sql' | 'bash';
  content: string;
  createdAt: number;
  updatedAt: number;
}

export interface CodeFolder {
  id: string;
  path: string;
  name: string;
}

export interface LinkItem {
  id: string;
  title: string;
  url: string;
  description?: string;
  tags: string[];
  category: string;
  safetyScore?: 'secure' | 'neutral' | 'onion' | 'caution';
  createdAt: number;
  notes?: string;
}

export interface TelegramConfig {
  botToken: string;
  chatId: string;
  enabled: boolean;
  autoSync: boolean;
  scrubAfterPush: boolean;
  lastSyncTime?: number | null;
  lastStatus?: string;
}

export interface SecuritySettings {
  autoLockMinutes: number;
  biometricsEnabled: boolean;
  biometricCredentialId?: string;
  duressPin: string; // Triggers decoy mode with fake data
  activeDecoy: CamouflageMode;
  autoLockOnBlur: boolean;
  stealthTabTitle: boolean;
  zeroTraceLogging: boolean;
  decoyTitle: string;
}

export interface SearchResultItem {
  id: string;
  title: string;
  snippet: string;
  type: 'note' | 'journal' | 'file' | 'code' | 'link';
  category: string;
  timestamp: number;
  targetView: ViewMode;
}

export interface VaultState {
  notes: NoteItem[];
  journal: JournalEntry[];
  files: VaultFile[];
  codeFiles: CodeFile[];
  codeFolders: CodeFolder[];
  links: LinkItem[];
  telegramConfig: TelegramConfig;
  securitySettings: SecuritySettings;
}

