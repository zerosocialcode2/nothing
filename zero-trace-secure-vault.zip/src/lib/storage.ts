/**
 * Zero-Knowledge Offline-First Storage Layer
 * Manages encrypted ciphertext persistence with complete zero-logging and instant memory shredding.
 */

import { NoteItem, JournalEntry, VaultFile, CodeFile, CodeFolder, LinkItem, TelegramConfig, SecuritySettings } from '../types';
import { encryptPayload, decryptPayload, calculateSha256 } from './crypto';

const STORAGE_KEY = 'zt_vault_payload_v1';
const SETTINGS_KEY = 'zt_vault_sec_config_v1';
const DURESS_KEY = 'zt_vault_duress_payload_v1';

export interface VaultState {
  notes: NoteItem[];
  journal: JournalEntry[];
  files: VaultFile[];
  codeFiles: CodeFile[];
  codeFolders: CodeFolder[];
  links: LinkItem[];
  telegramConfig: TelegramConfig;
  securitySettings: SecuritySettings;
}

export const DEFAULT_SECURITY_SETTINGS: SecuritySettings = {
  autoLockMinutes: 5,
  biometricsEnabled: true,
  duressPin: '9999',
  activeDecoy: 'none',
  autoLockOnBlur: true,
  stealthTabTitle: false,
  zeroTraceLogging: true,
  decoyTitle: 'System Task Manager',
};

export const DEFAULT_TELEGRAM_CONFIG: TelegramConfig = {
  botToken: '',
  chatId: '',
  enabled: false,
  autoSync: false,
  scrubAfterPush: false,
  lastSyncTime: null,
  lastStatus: 'Disconnected',
};

export function getInitialVaultData(): VaultState {
  const now = Date.now();
  return {
    notes: [
      {
        id: 'note-welcome',
        title: '🔒 Operational Security Manifesto',
        content: `# Operational Security & Playground Rules\n\n1. **Zero-Knowledge Principle**: Everything is encrypted client-side using **AES-GCM 256-bit** with PBKDF2 250,000 iterations before touching disk.\n2. **No Logs / No Analytics**: Zero telemetry, zero cookies, zero third-party trackers.\n3. **Panic Cloak**: Press \`Alt + P\` or click the Eye stealth icon to instantly cloak into a benign calculator or Linux terminal.\n4. **Telegram Cloud Dispersal**: Configure your Telegram Bot Token to push encrypted backups and purge local traces in 1-click.\n5. **Self-Destruct Notes**: Enable self-destruct timers on critical operational thoughts.`,
        tags: ['OpSec', 'Guidelines', 'Master'],
        pinned: true,
        createdAt: now - 3600000 * 24,
        updatedAt: now,
      },
      {
        id: 'note-keys',
        title: '🔑 Encrypted Keys & Passphrases',
        content: `### Cold Storage Seed Fragments\n\n- **Vault ID**: \`ZK-9082-ALPHA\`\n- **Hardware PGP Fingerprint**: \`8F9A 2B3C 4D5E 6F70 1A2B 3C4D 5E6F 7081\`\n- **Safety Canary**: The vault integrity hash is currently verified tamper-free.\n\n> "Paranoia is just a heightened state of awareness."`,
        tags: ['Keys', 'ColdStorage'],
        pinned: false,
        createdAt: now - 3600000 * 12,
        updatedAt: now - 3600000 * 4,
      }
    ],
    journal: [
      {
        id: 'journal-entry-1',
        title: 'Surveillance Assessment & Threat Level Scan',
        content: `Completed daily network inspection. Zero unusual telemetry packets detected. WebRTC leaks disabled. Switched DNS resolver to strict encrypted DNS-over-HTTPS. \n\nFeeling hyper-vigilant today. The vault provides a peaceful sanctuary to record unmonitored ideas without algorithm surveillance.`,
        date: new Date().toISOString().split('T')[0],
        timestamp: now - 3600000 * 8,
        paranoiaLevel: 4,
        mood: 'vigilant',
        securityAssessment: 'High Alert: Isolated local sandbox verified. Zero network leaks.',
        hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        previousHash: '0000000000000000000000000000000000000000000000000000000000000000',
        tags: ['Network', 'Assessment', 'OpSec'],
      }
    ],
    files: [
      {
        id: 'file-sample-manifesto',
        name: 'Confidential_Architecture.txt',
        size: 1420,
        mimeType: 'text/plain',
        category: 'document',
        dataUrl: 'data:text/plain;base64,' + btoa('ZERO-TRACE VAULT CONFIDENTIAL SPECIFICATION\n\nCipher: AES-256-GCM\nKey Derivation: PBKDF2 (SHA-256, 250k iterations)\nSteganography: Canvas RGB LSB Embedding\nNetwork: Offline-first with isolated Telegram bot egress option.\nTamper Detection: SHA-256 Merkle chain.'),
        tags: ['Spec', 'Classified'],
        createdAt: now - 3600000 * 16,
        notes: 'Core system specs and cryptographic blueprint.',
      }
    ],
    codeFiles: [
      {
        id: 'code-main-py',
        name: 'cipher_tool.py',
        path: 'src/cipher_tool.py',
        language: 'python',
        content: `#!/usr/bin/env python3
# Zero-Trace Secure Data Shuffler
import hashlib
import secrets

def generate_salt():
    return secrets.token_hex(16)

def hash_payload(data: str, salt: str) -> str:
    h = hashlib.sha256()
    h.update((data + salt).encode('utf-8'))
    return h.hexdigest()

if __name__ == '__main__':
    salt = generate_salt()
    secret = "Paranoid playground activated."
    print(f"Generated Salt: {salt}")
    print(f"Tamper Hash: {hash_payload(secret, salt)}")
`,
        createdAt: now - 3600000 * 20,
        updatedAt: now - 3600000 * 2,
      },
      {
        id: 'code-preview-html',
        name: 'sandbox_preview.html',
        path: 'src/sandbox_preview.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
  <style>
    body { background: #0b0d13; color: #10b981; font-family: monospace; padding: 20px; }
    .radar { width: 100px; height: 100px; border-radius: 50%; border: 2px solid #10b981; margin: 20px 0; animation: spin 4s linear infinite; }
    @keyframes spin { 0% { transform: rotate(0deg); opacity: 0.8; } 100% { transform: rotate(360deg); opacity: 0.2; } }
  </style>
</head>
<body>
  <h2>[ZERO TRACE SANDBOX]</h2>
  <p>Isolated Code Execution Container</p>
  <div class="radar"></div>
  <p>Status: All network interceptors active & silenced.</p>
</body>
</html>`,
        createdAt: now - 3600000 * 18,
        updatedAt: now - 3600000 * 18,
      }
    ],
    codeFolders: [
      { id: 'f-src', path: 'src', name: 'src' },
      { id: 'f-docs', path: 'docs', name: 'docs' },
    ],
    links: [
      {
        id: 'link-eff',
        title: 'Electronic Frontier Foundation (EFF)',
        url: 'https://www.eff.org',
        description: 'Defending digital privacy, free expression, and civil liberties.',
        category: 'Privacy',
        tags: ['OpSec', 'Rights', 'Essential'],
        safetyScore: 'secure',
        createdAt: now - 3600000 * 40,
        notes: 'Crucial reading on surveillance capitalism and defense guides.',
      },
      {
        id: 'link-tor',
        title: 'The Tor Project — Anonymity Online',
        url: 'https://www.torproject.org',
        description: 'Defend yourself against tracking and surveillance. Circumvent censorship.',
        category: 'Anonymity',
        tags: ['Onion', 'Tor', 'Bypass'],
        safetyScore: 'onion',
        createdAt: now - 3600000 * 30,
        notes: 'Primary resource for onion routing principles.',
      },
      {
        id: 'link-cryptome',
        title: 'Cryptome Archive',
        url: 'https://cryptome.org',
        description: 'Document archive on cryptography, privacy, surveillance, and national security.',
        category: 'Research',
        tags: ['Leaks', 'Crypto', 'Archive'],
        safetyScore: 'secure',
        createdAt: now - 3600000 * 20,
        notes: 'Historic repository of cryptography papers.',
      }
    ],
    telegramConfig: DEFAULT_TELEGRAM_CONFIG,
    securitySettings: DEFAULT_SECURITY_SETTINGS,
  };
}

// Decoy Vault for Duress PIN (Harmless generic notes)
export function getDecoyVaultData(): VaultState {
  const now = Date.now();
  return {
    notes: [
      {
        id: 'decoy-grocery',
        title: 'Weekly Grocery List',
        content: `- Whole Milk\n- Sourdough Bread\n- Eggs (1 Dozen)\n- Avocados\n- Olive Oil\n- Ground Coffee`,
        tags: ['Personal', 'Shopping'],
        pinned: true,
        createdAt: now - 86400000,
        updatedAt: now,
      },
      {
        id: 'decoy-movies',
        title: 'Movie Recommendations',
        content: `1. Inception\n2. The Grand Budapest Hotel\n3. Interstellar\n4. Knives Out`,
        tags: ['Entertainment'],
        pinned: false,
        createdAt: now - 43200000,
        updatedAt: now,
      }
    ],
    journal: [
      {
        id: 'decoy-j1',
        title: 'Weekend Garden Prep',
        content: 'Planted tomato seeds in the backyard. Weather was sunny and pleasant.',
        date: new Date().toISOString().split('T')[0],
        timestamp: now,
        paranoiaLevel: 1,
        mood: 'focused',
        securityAssessment: 'Normal daily log.',
        hash: 'decoy_hash_001',
        previousHash: '0000',
        tags: ['Daily'],
      }
    ],
    files: [],
    codeFiles: [
      {
        id: 'decoy-c1',
        name: 'hello_world.js',
        path: 'src/hello_world.js',
        language: 'javascript',
        content: `console.log("Hello from benign script!");`,
        createdAt: now,
        updatedAt: now,
      }
    ],
    codeFolders: [{ id: 'f-src', path: 'src', name: 'src' }],
    links: [
      {
        id: 'decoy-l1',
        title: 'Wikipedia',
        url: 'https://en.wikipedia.org',
        description: 'The Free Encyclopedia',
        category: 'Reference',
        tags: ['General'],
        safetyScore: 'secure',
        createdAt: now,
      }
    ],
    telegramConfig: DEFAULT_TELEGRAM_CONFIG,
    securitySettings: {
      ...DEFAULT_SECURITY_SETTINGS,
      duressPin: '9999',
    },
  };
}

// Check if an encrypted vault exists in local storage
export function hasExistingVault(): boolean {
  return !!localStorage.getItem(STORAGE_KEY);
}

// Save encrypted vault to local storage
export async function saveVault(vaultData: VaultState, passphrase: string): Promise<void> {
  const encryptedPayload = await encryptPayload(vaultData, passphrase);
  localStorage.setItem(STORAGE_KEY, encryptedPayload);
}

// Load and decrypt vault from local storage
export async function loadVault(passphrase: string): Promise<VaultState> {
  const rawEncrypted = localStorage.getItem(STORAGE_KEY);
  if (!rawEncrypted) {
    // Return initial seed and save it encrypted
    const initial = getInitialVaultData();
    await saveVault(initial, passphrase);
    return initial;
  }

  try {
    return await decryptPayload<VaultState>(rawEncrypted, passphrase);
  } catch (err) {
    throw new Error('Incorrect passphrase or corrupted encrypted database payload.');
  }
}

// Export raw encrypted file for manual physical cold storage backup
export function getRawEncryptedVault(): string | null {
  return localStorage.getItem(STORAGE_KEY);
}

// Import raw encrypted payload
export function importRawEncryptedVault(rawJson: string) {
  localStorage.setItem(STORAGE_KEY, rawJson);
}

// Extreme Security: Zero-Trace Shredder
export function purgeAllTraces(): void {
  // 1. Overwrite localStorage keys with random bytes
  const keys = Object.keys(localStorage);
  for (const k of keys) {
    const dummy = Array.from(window.crypto.getRandomValues(new Uint8Array(256))).map(b => b.toString(16)).join('');
    localStorage.setItem(k, dummy);
  }
  // 2. Clear all
  localStorage.clear();
  sessionStorage.clear();

  // 3. Clear caches if accessible
  if ('caches' in window) {
    caches.keys().then(names => {
      names.forEach(name => caches.delete(name));
    });
  }
}
