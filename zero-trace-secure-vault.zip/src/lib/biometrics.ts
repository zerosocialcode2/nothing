/**
 * WebAuthn / Biometric Authenticator
 * Provides hardware-backed biometric (TouchID, FaceID, Windows Hello, Android Biometrics)
 * or security key authentication with graceful fallback.
 */

export interface BiometricAvailability {
  isSupported: boolean;
  platformAuthenticator: boolean;
}

export async function checkBiometricSupport(): Promise<BiometricAvailability> {
  if (!window.PublicKeyCredential) {
    return { isSupported: false, platformAuthenticator: false };
  }

  try {
    const platformAuth = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    return {
      isSupported: true,
      platformAuthenticator: platformAuth,
    };
  } catch {
    return { isSupported: true, platformAuthenticator: false };
  }
}

export async function registerBiometric(username: string = 'paranoid-user'): Promise<string> {
  if (!window.PublicKeyCredential) {
    throw new Error('Biometric hardware authentication is not supported on this browser.');
  }

  const challenge = new Uint8Array(32);
  window.crypto.getRandomValues(challenge);

  const userId = new Uint8Array(16);
  window.crypto.getRandomValues(userId);

  const createOptions: PublicKeyCredentialCreationOptions = {
    challenge,
    rp: {
      name: 'Zero-Trace Vault',
      id: window.location.hostname || 'localhost',
    },
    user: {
      id: userId,
      name: username,
      displayName: 'Vault Operator',
    },
    pubKeyCredParams: [
      { alg: -7, type: 'public-key' }, // ES256
      { alg: -257, type: 'public-key' }, // RS256
    ],
    authenticatorSelection: {
      authenticatorAttachment: 'platform',
      userVerification: 'required',
      residentKey: 'preferred',
    },
    timeout: 60000,
    attestation: 'none',
  };

  try {
    const credential = (await navigator.credentials.create({
      publicKey: createOptions,
    })) as PublicKeyCredential;

    if (!credential) {
      throw new Error('Biometric registration was cancelled.');
    }

    return credential.id;
  } catch (err: any) {
    // If platform authenticator fails (e.g. cross-origin iframe restriction), provide clear explanation
    console.warn('Biometric registration notice:', err);
    throw new Error(err.message || 'Biometric registration failed. Please ensure biometrics/passkey is supported in your device.');
  }
}

export async function verifyBiometric(credentialId?: string): Promise<boolean> {
  if (!window.PublicKeyCredential) {
    throw new Error('Biometric hardware authentication not available.');
  }

  const challenge = new Uint8Array(32);
  window.crypto.getRandomValues(challenge);

  const getOptions: PublicKeyCredentialRequestOptions = {
    challenge,
    timeout: 60000,
    userVerification: 'required',
    rpId: window.location.hostname || 'localhost',
  };

  if (credentialId) {
    // Convert string credentialId to ArrayBuffer
    const binary = window.atob(credentialId.replace(/-/g, '+').replace(/_/g, '/'));
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    getOptions.allowCredentials = [
      {
        id: bytes.buffer,
        type: 'public-key',
      },
    ];
  }

  try {
    const assertion = await navigator.credentials.get({
      publicKey: getOptions,
    });

    return !!assertion;
  } catch (err: any) {
    console.warn('Biometric verification notice:', err);
    throw new Error(err.message || 'Biometric authentication was cancelled or failed.');
  }
}
