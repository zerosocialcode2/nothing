/**
 * Telegram Cloud Bridge for Zero-Trace Vault
 * Allows pushing encrypted zero-knowledge payloads and confidential documents
 * directly to a private Telegram Channel / Bot storage.
 */

export interface TelegramTestResult {
  success: boolean;
  botName?: string;
  botUsername?: string;
  chatTitle?: string;
  error?: string;
}

export async function testTelegramConnection(botToken: string, chatId: string): Promise<TelegramTestResult> {
  const cleanToken = botToken.trim();
  const cleanChat = chatId.trim();

  if (!cleanToken || !cleanChat) {
    return { success: false, error: 'Both Bot Token and Chat/Channel ID are required.' };
  }

  try {
    // 1. Verify Bot Token
    const getMeRes = await fetch(`https://api.telegram.org/bot${cleanToken}/getMe`);
    const getMeData = await getMeRes.json();

    if (!getMeData.ok) {
      return { success: false, error: `Invalid Bot Token: ${getMeData.description || 'Verification failed'}` };
    }

    // 2. Test send a handshake beacon to verify write access
    const msgRes = await fetch(`https://api.telegram.org/bot${cleanToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: cleanChat,
        text: `🔒 *Zero-Trace Vault Connected*\n\n📡 Handshake established at \`${new Date().toISOString()}\`\nStatus: *Encrypted & Ready*`,
        parse_mode: 'Markdown',
      }),
    });

    const msgData = await msgRes.json();
    if (!msgData.ok) {
      return {
        success: false,
        botName: getMeData.result.first_name,
        botUsername: getMeData.result.username,
        error: `Bot is valid (@${getMeData.result.username}), but cannot post to Chat ID (${cleanChat}): ${msgData.description}. Ensure bot is added as Administrator with Post Messages permission.`,
      };
    }

    return {
      success: true,
      botName: getMeData.result.first_name,
      botUsername: getMeData.result.username,
      chatTitle: msgData.result.chat?.title || `Chat ${cleanChat}`,
    };
  } catch (err: any) {
    return { success: false, error: `Network connection error: ${err.message || 'Check connection or bot token'}` };
  }
}

export async function sendTelegramMessage(botToken: string, chatId: string, message: string): Promise<boolean> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken.trim()}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId.trim(),
        text: message,
        parse_mode: 'Markdown',
      }),
    });
    const data = await res.json();
    return !!data.ok;
  } catch {
    return false;
  }
}

export async function sendTelegramDocument(
  botToken: string,
  chatId: string,
  blob: Blob,
  filename: string,
  caption?: string
): Promise<{ success: boolean; error?: string; messageId?: number }> {
  try {
    const formData = new FormData();
    formData.append('chat_id', chatId.trim());
    formData.append('document', blob, filename);
    if (caption) {
      formData.append('caption', caption);
      formData.append('parse_mode', 'Markdown');
    }

    const res = await fetch(`https://api.telegram.org/bot${botToken.trim()}/sendDocument`, {
      method: 'POST',
      body: formData,
    });

    const data = await res.json();
    if (!data.ok) {
      return { success: false, error: data.description || 'Upload failed' };
    }

    return { success: true, messageId: data.result.message_id };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network upload error' };
  }
}

export async function pushEncryptedBackupToTelegram(
  botToken: string,
  chatId: string,
  encryptedVaultPayload: string,
  stats: { notesCount: number; filesCount: number; journalCount: number; linksCount: number; codeCount: number }
): Promise<{ success: boolean; error?: string }> {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `vault-encrypted-backup-${timestamp}.ztvault`;
  const blob = new Blob([encryptedVaultPayload], { type: 'application/octet-stream' });

  const caption = `🔐 *Zero-Trace Encrypted Vault Backup*\n\n` +
    `📅 *Timestamp:* \`${new Date().toUTCString()}\`\n` +
    `📦 *Items:* ${stats.notesCount} notes, ${stats.journalCount} journal entries, ${stats.filesCount} files, ${stats.linksCount} links, ${stats.codeCount} code files\n` +
    `🛡️ *Cipher:* AES-GCM 256-bit (PBKDF2 250k)\n` +
    `⚡ *Status:* Encrypted payload dispatched`;

  return await sendTelegramDocument(botToken, chatId, blob, filename, caption);
}
