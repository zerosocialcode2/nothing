/**
 * Zero-Knowledge Cryptographic Engine
 * Uses modern Web Crypto API (AES-GCM 256-bit + PBKDF2 250k iterations + SHA-256)
 */

// Buffer / Base64 Helpers
export function arrayBufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
  let binary = '';
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

export function base64ToArrayBuffer(base64: string): Uint8Array {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Generate cryptographically secure random salt / IV
export function generateRandomBytes(length: number): Uint8Array {
  const bytes = new Uint8Array(length);
  window.crypto.getRandomValues(bytes);
  return bytes;
}

// Derive AES-GCM 256 key from passphrase and salt using PBKDF2
export async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: 250000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

// Encrypt plaintext string -> JSON payload { ciphertext, iv, salt }
export async function encryptText(plaintext: string, passphrase: string): Promise<{ ciphertext: string; iv: string; salt: string }> {
  const enc = new TextEncoder();
  const salt = generateRandomBytes(16);
  const iv = generateRandomBytes(12); // Standard 12 bytes for AES-GCM
  const key = await deriveKey(passphrase, salt);

  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv,
    },
    key,
    enc.encode(plaintext)
  );

  return {
    ciphertext: arrayBufferToBase64(encryptedBuffer),
    iv: arrayBufferToBase64(iv),
    salt: arrayBufferToBase64(salt),
  };
}

// Decrypt ciphertext string
export async function decryptText(
  ciphertext: string,
  iv: string,
  salt: string,
  passphrase: string
): Promise<string> {
  const dec = new TextDecoder();
  const saltBytes = base64ToArrayBuffer(salt);
  const ivBytes = base64ToArrayBuffer(iv);
  const cipherBytes = base64ToArrayBuffer(ciphertext);
  const key = await deriveKey(passphrase, saltBytes);

  const decryptedBuffer = await window.crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: ivBytes,
    },
    key,
    cipherBytes
  );

  return dec.decode(decryptedBuffer);
}

// Encrypt entire complex data payload (e.g. database, notes, files)
export async function encryptPayload<T>(payload: T, passphrase: string): Promise<string> {
  const jsonStr = JSON.stringify(payload);
  const encrypted = await encryptText(jsonStr, passphrase);
  return JSON.stringify(encrypted);
}

// Decrypt complex data payload
export async function decryptPayload<T>(encryptedJsonString: string, passphrase: string): Promise<T> {
  const parsed = JSON.parse(encryptedJsonString);
  const decryptedStr = await decryptText(parsed.ciphertext, parsed.iv, parsed.salt, passphrase);
  return JSON.parse(decryptedStr);
}

// Tamper-evident SHA-256 hash generator
export async function calculateSha256(data: string): Promise<string> {
  const enc = new TextEncoder();
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', enc.encode(data));
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Secure memory shredder
export function shredMemory(target: Uint8Array | ArrayBuffer | string[]) {
  if (target instanceof Uint8Array) {
    window.crypto.getRandomValues(target);
    target.fill(0);
  }
}

// Steganography: Encode hidden UTF-8 message into image canvas pixel LSBs
export async function hideMessageInImage(imageDataUrl: string, secretText: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('Canvas 2D not supported'));

      ctx.drawImage(img, 0, 0);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;

      // Prefix message with length header and delimiter
      const payload = `__ZTVAULT__:${secretText}__END__`;
      const enc = new TextEncoder();
      const bytes = enc.encode(payload);

      let bitIndex = 0;
      const totalBits = bytes.length * 8;
      const maxBits = data.length * 0.75; // Using RGB channels only

      if (totalBits > maxBits) {
        return reject(new Error('Image is too small to embed this payload safely'));
      }

      for (let i = 0; i < bytes.length; i++) {
        const byte = bytes[i];
        for (let b = 0; b < 8; b++) {
          const bit = (byte >> (7 - b)) & 1;
          const pixelIndex = Math.floor(bitIndex / 3) * 4 + (bitIndex % 3);
          data[pixelIndex] = (data[pixelIndex] & 0xfe) | bit;
          bitIndex++;
        }
      }

      ctx.putImageData(imgData, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('Failed to load image for steganography'));
    img.src = imageDataUrl;
  });
}

// Steganography: Extract hidden UTF-8 message from image canvas
export async function extractMessageFromImage(imageDataUrl: string): Promise<string | null> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('Canvas 2D not supported'));

      ctx.drawImage(img, 0, 0);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;

      const extractedBytes: number[] = [];
      let currentByte = 0;
      let bitCount = 0;
      let bitIndex = 0;
      const maxPixels = canvas.width * canvas.height;

      while (bitIndex < maxPixels * 3 && extractedBytes.length < 50000) {
        const pixelIndex = Math.floor(bitIndex / 3) * 4 + (bitIndex % 3);
        const bit = data[pixelIndex] & 1;
        currentByte = (currentByte << 1) | bit;
        bitCount++;

        if (bitCount === 8) {
          extractedBytes.push(currentByte);
          currentByte = 0;
          bitCount = 0;

          // Check for delimiter every 64 bytes
          if (extractedBytes.length % 32 === 0) {
            const dec = new TextDecoder();
            const sample = dec.decode(new Uint8Array(extractedBytes));
            if (sample.includes('__END__')) {
              break;
            }
          }
        }
        bitIndex++;
      }

      const dec = new TextDecoder();
      const fullText = dec.decode(new Uint8Array(extractedBytes));
      if (fullText.startsWith('__ZTVAULT__:') && fullText.includes('__END__')) {
        const secret = fullText.slice('__ZTVAULT__:'.length, fullText.indexOf('__END__'));
        resolve(secret);
      } else {
        resolve(null);
      }
    };
    img.onerror = () => reject(new Error('Failed to load image for extraction'));
    img.src = imageDataUrl;
  });
}

// Strip EXIF & metadata from image by re-rendering to fresh blank canvas
export async function stripImageMetadata(imageDataUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return resolve(imageDataUrl);

      // Clean render onto blank canvas removes all EXIF headers, GPS, camera serials
      ctx.drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('Failed to load image for metadata stripping'));
    img.src = imageDataUrl;
  });
}

// Cryptographic Password & Passphrase Generator
const DICEWARE_WORDLIST = [
  'cipher', 'shadow', 'quantum', 'tunnel', 'phantom', 'beacon', 'onyx', 'nebula',
  'matrix', 'glitch', 'sentinel', 'stealth', 'bastion', 'enigma', 'citadel', 'vector',
  'vertex', 'obsidian', 'aurora', 'vertex', 'stratum', 'solitude', 'zenith', 'pulse',
  'cascade', 'monolith', 'valkyrie', 'cobalt', 'solitary', 'vortex', 'shroud', 'flux',
  'specter', 'halcyon', 'perimeter', 'mirage', 'cryptic', 'anchor', 'protocol', 'relay'
];

export function generateSecurePassword(options: {
  type: 'passphrase' | 'random';
  length: number; // characters or words
  includeSymbols: boolean;
  includeNumbers: boolean;
}): string {
  if (options.type === 'passphrase') {
    const wordCount = Math.max(3, Math.min(8, options.length || 5));
    const words: string[] = [];
    for (let i = 0; i < wordCount; i++) {
      const randIndex = generateRandomBytes(1)[0] % DICEWARE_WORDLIST.length;
      words.push(DICEWARE_WORDLIST[randIndex]);
    }
    const sep = options.includeSymbols ? '-_!.'[generateRandomBytes(1)[0] % 4] : '-';
    let result = words.join(sep);
    if (options.includeNumbers) {
      result += sep + (generateRandomBytes(1)[0] % 100).toString().padStart(2, '0');
    }
    return result;
  } else {
    let chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (options.includeNumbers) chars += '0123456789';
    if (options.includeSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

    const charLen = chars.length;
    const bytes = generateRandomBytes(options.length || 20);
    let result = '';
    for (let i = 0; i < bytes.length; i++) {
      result += chars[bytes[i] % charLen];
    }
    return result;
  }
}
