import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  LockScreen,
} from './components/LockScreen';
import { StealthHeader } from './components/StealthHeader';
import { NotepadView } from './components/NotepadView';
import { JournalView } from './components/JournalView';
import { CodeWorkspace } from './components/CodeWorkspace';
import { LinksDepot } from './components/LinksDepot';
import { MediaViewer } from './components/MediaViewer';
import { VaultManager } from './components/VaultManager';
import { ParanoidTools } from './components/ParanoidTools';
import { TelegramBridge } from './components/TelegramBridge';
import { CamouflageView } from './components/CamouflageView';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { SettingsModal } from './components/SettingsModal';

import { ViewMode, VaultState, SecuritySettings, TelegramConfig, NoteItem, JournalEntry, VaultFile, CodeFile, CodeFolder, LinkItem } from './types';
import {
  hasExistingVault,
  loadVault,
  saveVault,
  getInitialVaultData,
  getDecoyVaultData,
  DEFAULT_SECURITY_SETTINGS,
  DEFAULT_TELEGRAM_CONFIG,
  purgeAllTraces
} from './lib/storage';
import { shredMemory } from './lib/crypto';

export default function App() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isDuressMode, setIsDuressMode] = useState(false);
  const [isFirstSetup, setIsFirstSetup] = useState(!hasExistingVault());
  const [currentView, setCurrentView] = useState<ViewMode>('vault');
  const [isDecoyActive, setIsDecoyActive] = useState(false);

  // Modals
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);

  // Vault Memory State (Active only in RAM while unlocked)
  const [vaultData, setVaultData] = useState<VaultState | null>(null);
  const passphraseRef = useRef<string>('');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Auto-lock timer ref
  const activityTimerRef = useRef<any>(null);
  const fileDialogOpenRef = useRef<number>(0);

  // Setup Network Listeners
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Lock Vault and Shred Volatile Keys from RAM
  const handleLockVault = useCallback(() => {
    setIsUnlocked(false);
    setIsDuressMode(false);
    passphraseRef.current = '';
    setVaultData(null);
    setSearchModalOpen(false);
    setSettingsModalOpen(false);
  }, []);

  // Reset Inactivity Timer on User Interaction
  const resetActivityTimer = useCallback(() => {
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    if (!isUnlocked || !vaultData) return;

    const timeoutMinutes = vaultData.securitySettings.autoLockMinutes || 5;
    activityTimerRef.current = setTimeout(() => {
      handleLockVault();
    }, timeoutMinutes * 60 * 1000);
  }, [isUnlocked, vaultData, handleLockVault]);

  // Global Activity Listeners
  useEffect(() => {
    if (!isUnlocked) return;

    const events = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
    const onUserAction = () => resetActivityTimer();

    events.forEach(ev => window.addEventListener(ev, onUserAction));
    resetActivityTimer();

    return () => {
      events.forEach(ev => window.removeEventListener(ev, onUserAction));
      if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    };
  }, [isUnlocked, resetActivityTimer]);

  // Track File Picker / Upload Interactions to prevent false blur locks
  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (target) {
        if (
          (target.tagName === 'INPUT' && (target as HTMLInputElement).type === 'file') ||
          target.closest('label')?.querySelector('input[type="file"]') ||
          target.closest('button[data-file-picker="true"]') ||
          target.closest('label')
        ) {
          fileDialogOpenRef.current = Date.now();
        }
      }
    };

    window.addEventListener('click', handleGlobalClick, true);
    return () => window.removeEventListener('click', handleGlobalClick, true);
  }, []);

  // Auto-Lock on Window Blur (only when explicitly enabled and not in file dialog or transient focus switch)
  useEffect(() => {
    const handleBlur = () => {
      // If a file picker was opened recently, do not lock
      if (Date.now() - fileDialogOpenRef.current < 20000) {
        return;
      }
      if (isUnlocked && vaultData?.securitySettings?.autoLockOnBlur) {
        handleLockVault();
      }
    };
    window.addEventListener('blur', handleBlur);
    return () => window.removeEventListener('blur', handleBlur);
  }, [isUnlocked, vaultData, handleLockVault]);

  // Keyboard Shortcuts (Panic Cloak: Alt+P, Search: Ctrl+K, Lock: Ctrl+L)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Panic / Stealth Cloak: Alt + P
      if (e.altKey && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        setIsDecoyActive(prev => !prev);
      }
      // Search: Ctrl+K or Cmd+K
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        if (isUnlocked) setSearchModalOpen(prev => !prev);
      }
      // Lock Vault: Ctrl+L or Cmd+L
      if ((e.ctrlKey || e.metaKey) && (e.key === 'l' || e.key === 'L')) {
        e.preventDefault();
        if (isUnlocked) handleLockVault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isUnlocked, handleLockVault]);

  // Unlock Handler
  const handleUnlock = async (passphrase: string, isDuress: boolean): Promise<boolean> => {
    try {
      if (isDuress) {
        // Unlock decoy fake vault
        const decoy = getDecoyVaultData();
        setVaultData(decoy);
        setIsDuressMode(true);
        setIsUnlocked(true);
        passphraseRef.current = passphrase;
        return true;
      }

      const data = await loadVault(passphrase);
      setVaultData(data);
      passphraseRef.current = passphrase;
      setIsUnlocked(true);
      setIsDuressMode(false);
      setIsFirstSetup(false);
      return true;
    } catch {
      return false;
    }
  };

  // Synchronize Vault Updates to Encrypted Local Persistence
  const handleSaveVaultState = async (updated: Partial<VaultState>) => {
    if (!vaultData) return;
    const nextState = { ...vaultData, ...updated };
    setVaultData(nextState);

    // If not in decoy mode, persist encrypted payload
    if (!isDuressMode && passphraseRef.current) {
      await saveVault(nextState, passphraseRef.current);
    }
  };

  // Passphrase Change / Re-Keying
  const handleChangePassphrase = async (oldPass: string, newPass: string): Promise<boolean> => {
    if (oldPass !== passphraseRef.current || !vaultData) {
      return false;
    }
    passphraseRef.current = newPass;
    await saveVault(vaultData, newPass);
    return true;
  };

  // Total counts for header stats
  const totalItemsCount = vaultData
    ? vaultData.notes.length +
      vaultData.journal.length +
      vaultData.files.length +
      vaultData.links.length +
      vaultData.codeFiles.length
    : 0;

  // Render Camouflage Decoy if Active
  if (isDecoyActive) {
    return <CamouflageView onExitDecoy={() => setIsDecoyActive(false)} />;
  }

  // Render Lock Screen if Locked
  if (!isUnlocked || !vaultData) {
    return (
      <LockScreen
        onUnlock={handleUnlock}
        onTriggerDecoy={() => setIsDecoyActive(true)}
        duressPin={DEFAULT_SECURITY_SETTINGS.duressPin}
        isFirstSetup={isFirstSetup}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-[#d4d4d4] flex flex-col font-sans selection:bg-blue-600/30 selection:text-white">
      {/* Stealth Status & Nav Bar */}
      <StealthHeader
        currentView={currentView}
        onSelectView={setCurrentView}
        onLock={handleLockVault}
        onTriggerDecoy={() => setIsDecoyActive(true)}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenTelegram={() => setCurrentView('telegram')}
        onOpenSettings={() => setSettingsModalOpen(true)}
        isOnline={isOnline}
        telegramConnected={vaultData.telegramConfig.enabled}
        itemCount={totalItemsCount}
      />

      {/* Main Sandbox Views */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {currentView === 'vault' && (
          <VaultManager
            files={vaultData.files}
            onSaveFiles={files => handleSaveVaultState({ files })}
            telegramConfig={vaultData.telegramConfig}
            onOpenMediaTab={fileId => setCurrentView('media')}
          />
        )}

        {currentView === 'notes' && (
          <NotepadView
            notes={vaultData.notes}
            onSaveNotes={notes => handleSaveVaultState({ notes })}
          />
        )}

        {currentView === 'journal' && (
          <JournalView
            entries={vaultData.journal}
            onSaveEntries={journal => handleSaveVaultState({ journal })}
          />
        )}

        {currentView === 'code' && (
          <CodeWorkspace
            files={vaultData.codeFiles}
            folders={vaultData.codeFolders}
            onSaveFiles={codeFiles => handleSaveVaultState({ codeFiles })}
            onSaveFolders={codeFolders => handleSaveVaultState({ codeFolders })}
          />
        )}

        {currentView === 'links' && (
          <LinksDepot
            links={vaultData.links}
            onSaveLinks={links => handleSaveVaultState({ links })}
          />
        )}

        {currentView === 'media' && (
          <MediaViewer
            files={vaultData.files}
            onSaveFiles={files => handleSaveVaultState({ files })}
          />
        )}

        {currentView === 'tools' && <ParanoidTools />}

        {currentView === 'telegram' && (
          <TelegramBridge
            config={vaultData.telegramConfig}
            onSaveConfig={telegramConfig => handleSaveVaultState({ telegramConfig })}
            stats={{
              notesCount: vaultData.notes.length,
              journalCount: vaultData.journal.length,
              filesCount: vaultData.files.length,
              linksCount: vaultData.links.length,
              codeCount: vaultData.codeFiles.length,
            }}
          />
        )}
      </main>

      {/* Global Universal Search Modal */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onNavigate={(view, itemId) => setCurrentView(view)}
        notes={vaultData.notes}
        journal={vaultData.journal}
        files={vaultData.files}
        codeFiles={vaultData.codeFiles}
        links={vaultData.links}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
        settings={vaultData.securitySettings}
        onSaveSettings={securitySettings => handleSaveVaultState({ securitySettings })}
        onChangePassphrase={handleChangePassphrase}
      />
    </div>
  );
}
